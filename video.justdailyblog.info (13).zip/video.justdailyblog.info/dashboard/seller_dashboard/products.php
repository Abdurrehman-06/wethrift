<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}

include "head.php";
include "../../includes/db_conn.php";

if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($conn, $_POST["title"]);
    $categories_id = mysqli_real_escape_string($conn, $_POST["categories_id"]);
    $subcategories_id = mysqli_real_escape_string($conn, $_POST["subcategories_id"]);
    $price = mysqli_real_escape_string($conn, $_POST["price"]);
    $stock = mysqli_real_escape_string($conn, $_POST["stock"]);
    // $discount = mysqli_real_escape_string($conn, $_POST["discount"]);
    $discount = isset($_POST["discount"]) ? $_POST["discount"] : ''; // Get the input from the form
$discount = str_replace(' ', ',', $discount); // Replace spaces with commas
$discount = preg_replace('/,+/', ',', $discount); // Remove duplicate commas
$discount = trim($discount, ','); // Trim leading and trailing commas
$discount = mysqli_real_escape_string($conn, $discount);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    $current_datetime = new DateTime("now", new DateTimeZone('UTC'));
    $current_datetime->setTimezone(new DateTimeZone('Europe/London'));
    $product_upload_date = $current_datetime->format('Y-m-d H:i:s');
    $sizes = ""; // Initialize the sizes variable
    
    // Check if sizes are selected
$sizes = ""; // Initialize the sizes variable

// Check if sizes are selected
if(isset($_POST['size'])) {
    $sizes = implode(",", $_POST['size']); // Concatenate selected sizes
}
    
    // File upload handling for multiple files
    $uploadDir = "uploads/";
    $uploadedFiles = [];

    // Loop through each uploaded file
    foreach ($_FILES['upload']['name'] as $index => $fileName) {
        $fileTmpName = $_FILES['upload']['tmp_name'][$index];
        $fileType = $_FILES['upload']['type'][$index];
        $fileSize = $_FILES['upload']['size'][$index];
        $fileError = $_FILES['upload']['error'][$index];
        if ($fileError === 0) {
            $fileNameNew = uniqid('', true) . "." . pathinfo($fileName, PATHINFO_EXTENSION);
            $fileDestination = $uploadDir . $fileNameNew;
            move_uploaded_file($fileTmpName, $fileDestination);
            $uploadedFiles[] = $fileDestination;
        } else {
            echo "Error uploading file.";
        }
    }
    
    if (!empty($uploadedFiles)) {
        $images = implode(',', $uploadedFiles);

        // Get user's email
        $user_id = $_SESSION['user_id'];
        $userEmailQuery = "SELECT email FROM users WHERE id = '$user_id'";
        $userEmailResult = mysqli_query($conn, $userEmailQuery);
        $row = mysqli_fetch_assoc($userEmailResult);
        $seller_email = $row['email'];

        // Insert data into database
        $sql = "INSERT INTO `products` (title, categories_id, subcategories_id, discount, size, price, stock, description, upload, seller_email, product_upload_date) 
                VALUES ('$title', '$categories_id', '$subcategories_id', '$discount', '$sizes', '$price', '$stock', '$description', '$images', '$seller_email', '$product_upload_date')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>window.location.href='products.php';</script>";
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "No files uploaded.";
    }

    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
<style>
.tag-container {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  align-items: center;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 300px;
}

.tag {
  background-color: #007bff;
  color: #fff;
  padding: 5px 10px;
  border-radius: 5px;
  cursor: pointer;
}

.tag:hover {
  background-color: #0056b3;
}

.tag-input {
  flex: 1;
  border: none;
  outline: none;
}
  .input-modal {
    width: 100%;
    border: 1px solid grey !important;
    border-radius: 3px;
  }
  .modal-content {
    border-radius: 10px;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
  }

  .modal-header {
    background-color: #007bff;
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
          .dropdown-menu.w-90 {
            padding-right: 0;
        }

  .modal-body {
    padding: 20px;
  }
  select.input-modal {
    width: 100%;
    border: 1px solid grey !important;
    border-radius: 3px;
    height: 38px;
    padding: 6px 12px;
    font-size: 1rem;
    line-height: 1.5;
    background-color: #fff;
    background-image: none;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  }
  /* Custom CSS for modal close button */
.modal-header .close {
  outline: none !important;
  opacity: 1 !important;
  background-color: #007bff !important;
    color: white !important;
    border:1px solid #007bff !important;
}
</style>
</head>
<body>
<?php include '../../includes/dashboard_navbar.php'; ?>
  <main id="main" class="main mt-4">
<?php if(isset($_GET['error'])){ ?>
            <div id="errorAlert" class="alert alert-danger" role="alert">
                <?php echo $_GET['error']; ?>
            </div>
        <?php } ?>

        <!-- Success message -->
        <?php if(isset($_GET['success'])){ ?>
            <div id="successAlert" class="alert alert-success" role="alert">
                <?php echo $_GET['success']; ?>
            </div>
        <?php } ?>
        <div class="text-left">
           <b class="fs-2"> Products By Seller</b>
        </div>
        <button type="button" class="btn btn-primary my-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Add new product
        </button>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add New Product</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="col-12">
          <form action="#" method="post" enctype="multipart/form-data">
            <div class="mb-3">
              <label for="title" class="form-label"><h6>Product Title</h6></label>
              <input class="input-modal form-control" type="text" name="title" id="title" required>
            </div>
            <?php 
                $select ="SELECT * FROM `shipping_cost`";
                $query = mysqli_query($conn,$select);
                $run = mysqli_fetch_assoc($query);
            
            ?>
            <div class="col-12 gap-1 d-flex">
            <div class="mb-3 col-6">
              <label for="price" class="form-label"><h6>Price <span style="font-size:12px;">(shipping fee will be <?= $run['shipping'] ?>)</span></h6></label>
              <input class="input-modal form-control" type="number" name="price" id="price" min="5" required>
                <div id="priceError" style="color: red; display: none; font-size: 13px;">Price must be upto ( €5 )</div>
            </div>
            <div class="mb-3 col-6">
              <label for="stock" class="form-label"><h6>Stock</h6></label>
              <input class="input-modal form-control" type="number" name="stock" id="stock" step="1" min="0" required>
            </div>
            </div>
            <div class="col-12 d-flex gap-1">
<div class="mb-3 col-6">
    <label for="cat" class="form-label"><h6>Categories</h6></label>
    <select name="categories_id" id="categories_id" class="form-select" required>
        <option value="" selected disabled>Select category</option>
        <?php 
        $categories = "SELECT * FROM `categories`";
        $sql = mysqli_query($conn, $categories);
        if ($sql) {
            foreach ($sql as $item) {
                ?>
                <option value="<?= $item['id']; ?>"><?= $item['categories']; ?></option>
                <?php 
            }
        } else {
            echo "<option disabled>No categories available</option>";
        }
        ?>
    </select>
</div>

<div class="mb-3 col-6">
    <label for="cat" class="form-label"><h6>Select SubCategories</h6></label>
    <select name="subcategories_id" id="sub_categories" class="form-select">
        <option value="" selected>Select Subcategories</option>
        <?php 
        $subcategories_query = "SELECT * FROM `subcategories`";
        $subcategories_result = mysqli_query($conn, $subcategories_query);
        if ($subcategories_result && mysqli_num_rows($subcategories_result) > 0) {
            while ($subcategory = mysqli_fetch_assoc($subcategories_result)) {
                ?>
                <option value="<?= $subcategory['id']; ?>"><?= $subcategory['sub_categories']; ?></option>
                <?php 
            }
        } else {
            echo "<option disabled>No subcategories available</option>";
        }
        ?>
    </select>
</div>
</div>



<div class='mb-3'>
    <label for='sizeType' class='form-label'><h6>Select Type</h6></label><br>
    <select class='form-select' id='sizeType'>
        <option value='garments'>Clothes</option>
        <option value='shoes'>Shoes</option>
    </select>
</div>

<div class='mb-3' id='sizeOptions'>
    <label for='size' class='form-label'><h6>Size</h6></label><br>
    <div class='input-modal' style='display: inline-block;'>
        <!-- Default size options -->
        <input type='checkbox' name='size[]' value='XS' class='form-check-input' id='sizeXS' >
        <label for='sizeXS' class='form-check-label'>XS</label>

        <input type='checkbox' name='size[]' value='S' class='form-check-input' id='sizeS'>
        <label for='sizeS' class='form-check-label'>S</label>

        <input type='checkbox' name='size[]' value='M' class='form-check-input' id='sizeM'>
        <label for='sizeM' class='form-check-label'>M</label>

        <input type='checkbox' name='size[]' value='L' class='form-check-input' id='sizeL'>
        <label for='sizeL' class='form-check-label'>L</label>

        <input type='checkbox' name='size[]' value='XL' class='form-check-input' id='sizeXL'>
        <label for='sizeXL' class='form-check-label'>XL</label>

        <input type='checkbox' name='size[]' value='XXL' class='form-check-input' id='sizeXXL'>
        <label for='sizeXXL' class='form-check-label'>XXL</label>

        <input type='checkbox' name='size[]' value='XXXL' class='form-check-input' id='sizeXXXL'>
        <label for='sizeXXXL' class='form-check-label'>XXXL</label>
    </div>
</div>


            <div class="mb-3">
              <label for="discount" class="form-label"><h6>Color(Use comma','to differentiate two colors)</h6></label> 
               <input class="input-modal form-control" type="text" name="discount" id="title" placeholder="(Enter your colors)" required>
            </div>
            <div class="mb-3">
              <label for="description" class="form-label"><h6>Description</h6></label>
              <textarea class="input-modal form-control" name="description" id="description" rows="3" maxlength="250" required></textarea>
<small class="text-muted">Maximum 250 characters</small>
            </div>
<div class="mb-3">
    <label for="upload" class="form-label">Upload Images</label>
    <input class="input-modal form-control" type="file" name="upload[]" id="upload" multiple required>
</div>
            <button type="submit" name="submit" class="btn btn-primary mt-2">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
$user_id = $_SESSION['user_id'];
$userEmailQuery = "SELECT email FROM users WHERE id = '$user_id'";
$userEmailResult = mysqli_query($conn, $userEmailQuery);
$row = mysqli_fetch_assoc($userEmailResult);
$seller_email = $row['email'];
$query = "SELECT * FROM `products` WHERE seller_email = '$seller_email' ORDER BY id DESC ";
$data = mysqli_query($conn, $query);

if(mysqli_num_rows($data) > 0) {
?>
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Title</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Update Details</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
<?php

  while ($result = mysqli_fetch_assoc($data)) {
      $id = $result['id']; 
      $categories_id = $result['categories_id'];
                $select_cat = "SELECT * FROM `categories` WHERE id = '$categories_id'";
                $run = mysqli_query($conn, $select_cat);
                $categories = mysqli_fetch_assoc($run);
                $imagePaths = explode(',', $result['upload']);
$firstImagePath = isset($imagePaths[0]) ? $imagePaths[0] : '';
      ?>
<tr>
    <td><?= $result['id'] ?></td>
    <td><a href="../../ecommerce/product-detail.php?id=<?= $id ?>"><img src='<?= $firstImagePath ?>' width='100px' height='auto'></a></td>
    <td><a href="../../ecommerce/product-detail.php?id=<?= $id ?>" style="color:black;"><?= $result['title'] ?> </a></td>
    <td><?= $result['price'] ?></td>
    <td><?= $result['stock'] ?></td>
    <td><button type='button' class="btn" style="background:black ; color:white" data-toggle='modal' data-target='#updateModal<?= $id ?>'><i class="fa-regular fa-pen-to-square"></i>Update</button></td>
    <td>
    <form action='delete_products.php' method='GET'>
        <input type='hidden' name='id' value='<?= $id ?>'>
        <button type='submit' class='btn btn-danger' onclick="return confirm('Are you sure you want to delete this product?')">
            <i class="fa-regular fa-trash-can"></i>Delete
        </button>
    </form>
</td>

</tr>

<?php
echo "
<div class='modal fade' id='updateModal{$id}' tabindex='-1' role='dialog' aria-labelledby='updateModalLabel{$id}' aria-hidden='true'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='updateModalLabel{$id}'>Update Product</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
        <form action='update_products.php' method='post' enctype='multipart/form-data'>
          <input type='hidden' name='id' value='{$id}'> <!-- Hidden input to send product ID -->
          <div class='form-group'>
            <label for='title'>Product Title</label>
            <input type='text' class='form-control' id='title' name='title' value='{$result['title']}' required>
          </div>
          <div class='form-group'>
            <label for='categories_id'>Categories</label>
            <select class='form-control' id='categories_id' name='categories_id' required>
              <option value=''>Select category</option>";
                $categoriesQuery = "SELECT * FROM categories";
                $categoriesResult = mysqli_query($conn, $categoriesQuery);
                if ($categoriesResult && mysqli_num_rows($categoriesResult) > 0) {
                    while ($row = mysqli_fetch_assoc($categoriesResult)) {
                        $selected = ($row['id'] == $result['categories_id']) ? 'selected' : '';
                        echo "<option value='{$row['id']}' $selected>{$row['categories']}</option>";
                    }
                }
                echo "
            </select>
          </div>
          <div class='form-group'>
            <label for='subcategories_id'>Subcategories</label>
            <select class='form-control' id='subcategories_id' name='subcategories_id'>
              <option value=''>Select subcategory</option>";
                $subcategories_query = "SELECT * FROM `subcategories`";
                $subcategories_result = mysqli_query($conn, $subcategories_query);
                if ($subcategories_result && mysqli_num_rows($subcategories_result) > 0) {
                    while ($subcategory = mysqli_fetch_assoc($subcategories_result)) {
                        $selected = ($subcategory['id'] == $result['subcategories_id']) ? 'selected' : '';
                        echo "<option value='{$subcategory['id']}' $selected>{$subcategory['sub_categories']}</option>";
                    }
                } else {
                    echo "<option disabled>No subcategories available</option>";
                }
                echo "
            </select>
          </div>
          <div class='mb-3'>
            <label for='size' class='form-label'><h6>Size</h6></label><br>
            <div class='input-modal' style='display: inline-block;'>
                <input type='checkbox' name='size[]' value='XS' class='form-check-input' id='sizeXS' ".(strpos($result['size'], 'XS') !== false ? 'checked' : '').">
                <label for='sizeXS' class='form-check-label'>XS</label>

                <input type='checkbox' name='size[]' value='S' class='form-check-input' id='sizeS' ".(strpos($result['size'], 'S') !== false ? 'checked' : '').">
                <label for='sizeS' class='form-check-label'>S</label>

                <input type='checkbox' name='size[]' value='M' class='form-check-input' id='sizeM' ".(strpos($result['size'], 'M') !== false ? 'checked' : '').">
                <label for='sizeM' class='form-check-label'>M</label>

                <input type='checkbox' name='size[]' value='L' class='form-check-input' id='sizeL' ".(strpos($result['size'], 'L') !== false ? 'checked' : '').">
                <label for='sizeL' class='form-check-label'>L</label>

                <input type='checkbox' name='size[]' value='XL' class='form-check-input' id='sizeXL' ".(strpos($result['size'], 'XL') !== false ? 'checked' : '').">
                <label for='sizeXL' class='form-check-label'>XL</label>

                <input type='checkbox' name='size[]' value='XXL' class='form-check-input' id='sizeXXL' ".(strpos($result['size'], 'XXL') !== false ? 'checked' : '').">
                <label for='sizeXXL' class='form-check-label'>XXL</label>

                <input type='checkbox' name='size[]' value='XXXL' class='form-check-input' id='sizeXXXL' ".(strpos($result['size'], 'XXXL') !== false ? 'checked' : '').">
                <label for='sizeXXXL' class='form-check-label'>XXXL</label>
            </div>
          </div>
          <div class='form-group'>
            <label for='price'>Original Price</label>
            <input class='form-control' type='number' name='price' id='price' value='{$result['price']}' min='5' required>
          </div>
          <div class='form-group'>
            <label for='stock'>Stock</label>
            <input class='form-control' type='number' name='stock' id='stock' value='{$result['stock']}' required>
          </div>
          <div class='form-group'>
            <label for='color'>Color(Use comma ',' to differentiate two colors)</label>
            <input class='form-control' type='text' name='color' id='color' value='{$result['discount']}' required>
          </div>
          <div class='form-group'>
            <label for='description'>Description</label>
            <textarea class='form-control' name='description' id='description' rows='3' required>{$result['description']}</textarea>
          </div>
          <div class='form-group'>
            <label for='upload'>Upload Image</label>
            <input class='form-control' type='file' name='upload' id='upload' >
          </div>
          <button type='submit' name='update' class='btn btn-dark'>Update</button>
        </form>
      </div>
    </div>
  </div>
</div>";
    }
?>

    </tbody>
  </table>
<?php
} else {
  
}
?>
  </main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('#categories_id').change(function(){
        var category_id = $(this).val();
        $.ajax({
            url: 'get_subcategories.php',
            type: 'post',
            data: {category_id: category_id},
            dataType: 'json',
            success:function(response){
                var len = response.length;
                $("#sub_categories").empty(); // Clear previous options
                $("#sub_categories").append("<option value='' selected>Select Subcategories</option>"); // Add empty option
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['sub_categories'];
                    $("#sub_categories").append("<option value='"+id+"'>"+name+"</option>");
                }
            }
        });
    });
});
</script>
  <script>
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    const myModal = document.getElementById('myModal')
    const myInput = document.getElementById('myInput')
    myModal.addEventListener('shown.bs.modal', () => {
      myInput.focus()
    })
    
  $(document).ready(function() {
    $('.dropdown-toggle').dropdown();
  });

       window.onload = function() {
        setTimeout(function() {
            var errorAlert = document.getElementById('errorAlert');
            var successAlert = document.getElementById('successAlert');
            if (errorAlert) {
                errorAlert.style.display = 'none';
            }
            if (successAlert) {
                successAlert.style.display = 'none';
            }
        }, 3000); // 3000 milliseconds = 3 seconds
    }; 
    const tagContainer = document.getElementById('tag-container');
    const tagInput = document.getElementById('tag-input');

    tagInput.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevent form submission
            if (this.value.trim() !== '') {
                const tag = this.value.trim();
                const tagElement = document.createElement('div');
                tagElement.classList.add('tag');
                tagElement.textContent = tag;
                tagContainer.insertBefore(tagElement, tagInput);
                this.value = '';
            }
        }
    });

  </script>
  <script>
    document.getElementById('price').addEventListener('input', function() {
        var price = this.value;
        var priceError = document.getElementById('priceError');

        if (price < 5) {
            priceError.style.display = 'block';
            this.setCustomValidity('Your price is too low (minimum: 5)');
        } else {
            priceError.style.display = 'none';
            this.setCustomValidity('');
        }
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script>
    // JavaScript to remove the alerts after 3 seconds
    window.onload = function() {
        setTimeout(function() {
            var errorAlert = document.getElementById('errorAlert');
            var successAlert = document.getElementById('successAlert');
            if (errorAlert) {
                errorAlert.style.display = 'none';
            }
            if (successAlert) {
                successAlert.style.display = 'none';
            }
        }, 3000); // 3000 milliseconds = 3 seconds
    };
    document.getElementById('upload').addEventListener('change', function(event) {
    var files = event.target.files;
    // Check if more than 4 files are selected
    if (files.length > 4) {
        alert('You can only upload up to 4 images.');
        // Clear the file input
        this.value = "";
    }
});
</script>
<script>
document.getElementById('sizeType').addEventListener('change', function() {
    var sizeType = this.value;
    var sizeOptionsDiv = document.getElementById('sizeOptions');
    // Clear existing size options
    sizeOptionsDiv.innerHTML = '';

    if (sizeType === 'garments') {
        sizeOptionsDiv.innerHTML = `
            <label for='size' class='form-label'><h6>Size</h6></label><br>
            <div class='input-modal' style='display: inline-block;'>
                <input type='checkbox' name='size[]' value='XS' class='form-check-input' id='sizeXS' >
                <label for='sizeXS' class='form-check-label'>XS</label>

                <input type='checkbox' name='size[]' value='S' class='form-check-input' id='sizeS'>
                <label for='sizeS' class='form-check-label'>S</label>

                <input type='checkbox' name='size[]' value='M' class='form-check-input' id='sizeM'>
                <label for='sizeM' class='form-check-label'>M</label>

                <input type='checkbox' name='size[]' value='L' class='form-check-input' id='sizeL'>
                <label for='sizeL' class='form-check-label'>L</label>

                <input type='checkbox' name='size[]' value='XL' class='form-check-input' id='sizeXL'>
                <label for='sizeXL' class='form-check-label'>XL</label>

                <input type='checkbox' name='size[]' value='XXL' class='form-check-input' id='sizeXXL'>
                <label for='sizeXXL' class='form-check-label'>XXL</label>

                <input type='checkbox' name='size[]' value='XXXL' class='form-check-input' id='sizeXXXL'>
                <label for='sizeXXXL' class='form-check-label'>XXXL</label>
            </div>`;
    } else if (sizeType === 'shoes') {
        // Add shoe size options
        sizeOptionsDiv.innerHTML = `
            <label for='size' class='form-label'><h6>Shoe Size</h6></label><br>
            <div class='input-modal' style='display: inline-block;'>
                <!-- Shoe size options -->
                <input type='checkbox' name='size[]' value='37' class='form-check-input' id='size37' >
                <label for='size37' class='form-check-label'>37</label>

                <input type='checkbox' name='size[]' value='38' class='form-check-input' id='size38'>
                <label for='size38' class='form-check-label'>38</label>

                <input type='checkbox' name='size[]' value='39' class='form-check-input' id='size39'>
                <label for='size39' class='form-check-label'>39</label>

                <input type='checkbox' name='size[]' value='40' class='form-check-input' id='size40'>
                <label for='size40' class='form-check-label'>40</label>

                <input type='checkbox' name='size[]' value='41' class='form-check-input' id='size41'>
                <label for='size41' class='form-check-label'>41</label>

                <input type='checkbox' name='size[]' value='42' class='form-check-input' id='size42'>
                <label for='size42' class='form-check-label'>42</label>

                <input type='checkbox' name='size[]' value='43' class='form-check-input' id='size43'>
                <label for='size43' class='form-check-label'>43</label>

                <input type='checkbox' name='size[]' value='44' class='form-check-input' id='size44'>
                <label for='size44' class='form-check-label'>44</label>

                <input type='checkbox' name='size[]' value='45' class='form-check-input' id='size45'>
                <label for='size45' class='form-check-label'>45</label>
            </div>`;
    }
});
</script>

</body>

</html>