<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}
include "head.php";
include "../../includes/db_conn.php";
$user_id = $_SESSION['user_id'];
$select_user_email = "SELECT email FROM users WHERE id = $user_id";
$result_user_email = mysqli_query($conn, $select_user_email);
$user_email_row = mysqli_fetch_assoc($result_user_email);
$seller_email = $user_email_row['email'];
$select_orders = "SELECT * FROM orders WHERE product_id IN (SELECT id FROM products WHERE seller_email = '$seller_email')";
$result_orders = mysqli_query($conn, $select_orders);

?>

<!DOCTYPE html>
<html lang="en">

<body>

    <?php include '../../includes/dashboard_navbar.php'; ?>
<main id="main" class="main mt-5">
    <div class="pagetitle">
        <table class="table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Billing Address</th>
                    <th>Buyer Name</th>
                    <th>Buyer Email</th>
                    <th>Buyer Number</th>
                    <th>Order Date</th>
                    <th>Payment Method</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($order = mysqli_fetch_assoc($result_orders)) {
                    $product_id = $order['product_id'];
                    $select_product = "SELECT * FROM products WHERE id = $product_id AND seller_email = '$seller_email' AND status = '1'";
                    $result_product = mysqli_query($conn, $select_product);
                    $product = mysqli_fetch_assoc($result_product);
                    if ($product) {
                ?>
                    <tr>
                        <td><a href="../../ecommerce/product-detail.php?id=<?= $order['product_id'] ?>"><img src="<?php echo $product['upload']; ?>" style="width: 100px;"></a></td>
                        <td ><a href="../../ecommerce/product-detail.php?id=<?= $order['product_id'] ?>"  class="text-dark" ><?php echo $product['title']; ?></a></td>
                        <td>€<?php echo $product['price']; ?></td>
                        <td><?php echo $order['p_qty']; ?></td>
                        <td><?php echo $order['billing_address']; ?></td>
                        <td><?php echo $order['buyer_name']; ?></td>
                        <td><?php echo $order['buyer_email']; ?></td>
                        <td><?php echo $order['billing_number']; ?></td>
                        <td><?php echo $order['order_date']; ?></td>
                        <td><?php echo $order['payment_method']; ?></td>
                    </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</main>


    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <script src="../assets/js/main.js"></script>

</body>

</html>
