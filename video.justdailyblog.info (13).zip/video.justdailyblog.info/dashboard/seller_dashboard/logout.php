<?php
session_start();

if (isset($_GET['confirm']) && $_GET['confirm'] === 'true') {
    // If confirmed, proceed with logout
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

// Add JavaScript for confirmation alert
echo '<script type="text/javascript">';
echo 'function confirmLogout() {';
echo 'if (confirm("Are you sure you want to log out?")) {';
echo 'window.location.href = "logout.php?confirm=true";';
echo '}';
echo '}';
echo '</script>';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">-

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link rel="stylesheet" href="../style2.css">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: Jan 29 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="col-12 d-flex  justify-content-between">
      <div class="col-md-4 d-flex justify-content-start">
        <a href="#" class="logo d-flex align-items-center">
          <img src="../../assets/img/dashboard/logo.05b9ef59.svg" alt="">
        </a>
      </div>
      <div class="col-4 sellers-dash">
        <a href="#" class="logo sellers-logo d-flex text-dark align-items-center">
          <h4>Sellers Dashboard</h4>
        </a>
      </div>
      -<div class="col-md-4 d-flex justify-content-end pe-md-5 pe-3">
        <i class="bi bi-list toggle-sidebar-btn"></i>
      </div>
    </div>

  

  </header><!-- End Header -->

<?php include '../../includes/dashboard_navbar.php'; ?>

  <main id="main" class="main">

    <div class="pagetitle">
     
    </div><!-- End Page Title -->


   
    
  

  </main><!-- End #main -->


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script>

    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

  </script>


  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>

</html>

