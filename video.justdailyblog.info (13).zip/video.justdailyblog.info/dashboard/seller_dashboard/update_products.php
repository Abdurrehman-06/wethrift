<?php
// Establish database connection
include "../../includes/db_conn.php";

// Check if form is submitted for update
if (isset($_POST['update'])) {
    // Retrieve form data
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $title = mysqli_real_escape_string($conn, $_POST["title"]);
    $categories_id = mysqli_real_escape_string($conn, $_POST["categories_id"]);
    $subcategories_id = mysqli_real_escape_string($conn, $_POST["subcategories_id"]);
    
    // Retrieve previous category and subcategory ID if not updated
    if (empty($categories_id) && empty($subcategories_id)) {
        $previousCategoryQuery = "SELECT categories_id, subcategories_id FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $previousCategoryQuery);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $previousCategory, $previousSubcategory);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $categories_id = $previousCategory;
        $subcategories_id = $previousSubcategory;
    } elseif (empty($categories_id)) {
        // Retrieve previous category ID if subcategory is not updated
        $previousCategoryQuery = "SELECT categories_id FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $previousCategoryQuery);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $previousCategory);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $categories_id = $previousCategory;
    } elseif (empty($subcategories_id)) {
        // Retrieve previous subcategory ID if category is not updated
        $previousSubcategoryQuery = "SELECT subcategories_id FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $previousSubcategoryQuery);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $previousSubcategory);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $subcategories_id = $previousSubcategory;
    }
    
    // Check if new sizes are provided
    if (isset($_POST['size'])) {
        $size = mysqli_real_escape_string($conn, implode(", ", $_POST["size"]));
    } else {
        // No new sizes provided, fetch previous sizes from the database
        $previousSizeQuery = "SELECT size FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $previousSizeQuery);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $previousSize);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $size = $previousSize;
    }

    $price = mysqli_real_escape_string($conn, $_POST["price"]);
    $color = mysqli_real_escape_string($conn, $_POST["color"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    
    // Check if a new file is uploaded
    if (!empty($_FILES["upload"]["name"])) {
        // Handle file upload
        $uploadDir = "uploads/";
        $uploadFile = $uploadDir . basename($_FILES["upload"]["name"]);
        move_uploaded_file($_FILES["upload"]["tmp_name"], $uploadFile);
        $uploadFilePath = $uploadFile;
    } else {
        // No new file uploaded, retrieve the previous image path from the database
        $previousImageQuery = "SELECT upload FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $previousImageQuery);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $previousImage);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $uploadFilePath = $previousImage;
    }

    // Update data in database using prepared statement
    $sql = "UPDATE products SET 
            title=?, 
            categories_id=?, 
            subcategories_id=?, 
            size=?, 
            price=?, 
            discount=?, 
            description=?, 
            upload=? 
            WHERE id=?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssssssi", $title, $categories_id, $subcategories_id, $size, $price, $color, $description, $uploadFilePath, $id);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: products.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}
?>
