<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit;
}
include "../../includes/db_conn.php";
include "head.php";

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $username = $row['username'];
    $birthdate = $row['birthdate'];
    $phone_number = $row['phone_number'];
    $email = $row['email'];
    $street_address = $row['street_address'];
    $password = $row['password'];
    $profile_image = $row['profile_image'];
} else {
    echo "User not found.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $street_address = mysqli_real_escape_string($conn, $_POST['street_address']);

    // Handle file upload for profile image
    if ($_FILES['profile_image']['size'] > 0) {
        $target_dir = "../user_dashboard/uploads/";
        $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
            $profile_image = $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Handle password change
    $old_password = mysqli_real_escape_string($conn, $_POST['old_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    if (!empty($old_password) && !empty($new_password)) {
        if (password_verify($old_password, $password)) {
            if (strlen($new_password) >= 8) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE users SET password='$hashed_password' WHERE id='$user_id'";
                mysqli_query($conn, $update_sql);
            } else {
                $errormessage = "New password must be at least 8 characters long.";
            }
        } else {
            $errormessage1 = "Old password is incorrect.";
        }
    }
    $update_sql = "UPDATE users SET username='$username', birthdate='$birthdate', phone_number='$phone_number', street_address='$street_address', profile_image='$profile_image' WHERE id='$user_id'";
    if (mysqli_query($conn, $update_sql)) {
        $_SESSION['success_msg'] = "Profile updated successfully.";
        header("Location: dashboard.php");
        exit;
    } else {
        echo "Error updating profile: " . mysqli_error($conn);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link rel="stylesheet" href="../style2.css">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
      body {
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

label {
    font-weight: bold;
}
 input[type="text"],
        input[type="date"],
        input[type="password"],
        input[type="email"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}
 .profile-img {
        position: relative;
        width: 150px;
        height: 150px;
        margin: auto;
        border-radius: 50%;
        overflow: hidden;
        cursor: pointer; /* Make the profile image clickable */
    }

    .profile-img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black overlay */
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .profile-img:hover .overlay {
        opacity: 1;
    }

    .overlay i {
        color: #fff;
        font-size: 24px;
        cursor: pointer;
    }
  </style>
</head>
<body>
    
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="col-12 d-flex  justify-content-between">
      <div class="col-md-4 d-flex justify-content-start">
        <a href="#" class="logo d-flex align-items-center">
          <img src="../../assets/img/dashboard/logo.05b9ef59.svg" alt="">
        </a>
      </div>
      <div class="col-4 sellers-dash">
        <a href="#" class="logo sellers-logo d-flex text-dark align-items-center">
          <h4>Sellers Dashboard</h4>
        </a>
      </div>
      <div>
      <div class="col-md-4 d-flex justify-content-end pe-md-5 pe-3">
        <i class="bi bi-list toggle-sidebar-btn"></i>
      </div>
    </div>
  </header>

    <?php include '../../includes/dashboard_navbar.php'; ?>

    <main id="main" class="main mt-5">
       <?php if(isset($errormessage1) || isset($errormessage)): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo $errormessage1; ?>
    </div>
<?php endif; ?>
        <div class="container">
            <h2>Profile</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data" onsubmit="return validateForm()">
                
                 <div class="profile-img" onclick="document.getElementById('file-input').click();">
                    <?php if(!empty($profile_image)): ?>
                        <img src="../user_dashboard/<?php echo $profile_image; ?>" alt="Profile Image">
                    <?php else: ?>
                        <!-- Display a default image if profile image is not set -->
                        <img src="../../user_dashboard/uploads/default.jpg" alt="Default Profile Image">
                    <?php endif; ?>
                    <div class="overlay">
                        <i class="fas fa-camera"></i>
                    </div>
                    <input type="file" name="profile_image" accept="image/*" id="file-input" style="display: none;">
                </div>
                
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo $username; ?>"><br><br>

                <label for="birthdate">Birthdate:</label>
                <input type="date" id="birthdate" name="birthdate" value="<?php echo $birthdate; ?>"><br><br>

                <label for="phone_number">Phone Number:</label>
                <input type="text" id="phone_number" name="phone_number" value="<?php echo $phone_number; ?>"><br><br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $email; ?>" disabled><br><br>

                <label for="old_password">Old Password:</label>
                <input type="password" id="old_password" name="old_password">
                <br><br>
    
<label for="new_password">New Password:</label>
<input type="password" id="new_password" name="new_password" oninput="validatePassword()"><br>
<small id="password_error" style="color: red; display: none;">Password must be at least 8 characters long</small><br><br>

                <input type="submit" value="Save">
            </form>
        </div>
    </main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?php include "../footer.php"; ?>
  <script>

    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

  </script>
  <script src="../assets/js/main.js"></script>
  <script>
    setTimeout(function(){
        document.querySelector('.alert').style.display = 'none';
    }, 5000); // Close the alert after 5 seconds (5000 milliseconds)
</script>
<script>
    function validatePassword() {
        var passwordInput = document.getElementById('new_password');
        var errorText = document.getElementById('password_error');

        if (passwordInput.value.length < 8) {
            errorText.style.display = 'block';
        } else {
            errorText.style.display = 'none';
        }
    }

    function validateForm() {
        var passwordInput = document.getElementById('new_password');
        if (passwordInput.value.length < 8) {
            var errorText = document.getElementById('password_error');
            errorText.style.display = 'block';
            return false; // Prevent form submission
        }
        return true; // Allow form submission
    }
</script>
</body>
</html>
