<?php
session_start();
include "../../includes/db_conn.php";
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $sql = "DELETE FROM products WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    if($result) {
        header("Location: products.php?success=product deleted successfully.");
        exit();
    } else {
        header("Location: products.php?error=Error deleting product.");
        exit();
    }
} else {
    header("Location: products.php?error=User ID not provided.");
    exit();
}
?>