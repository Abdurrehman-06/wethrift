<?php
include "../../includes/db_conn.php";

if(isset($_POST['category_id'])){
    $category_id = $_POST['category_id'];
    $sub_categories = "SELECT * FROM `subcategories` WHERE categories_id = $category_id";
    $sql = mysqli_query($conn, $sub_categories);
    $response = array();
    while($row = mysqli_fetch_assoc($sql)){
        $response[] = $row;
    }
    
    echo json_encode($response);
    exit;
}
?>