<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}
include "head.php";
include "../../includes/db_conn.php";
$user_id = $_SESSION['user_id'];
$select_user_email = "SELECT email FROM users WHERE id = $user_id";
$result_user_email = mysqli_query($conn, $select_user_email);
$user_email_row = mysqli_fetch_assoc($result_user_email);
$seller_email = $user_email_row['email'];
$monthly_earnings = array_fill(0, 12, 0);

$select_orders = "SELECT * FROM orders WHERE product_id IN (SELECT id FROM products WHERE seller_email = '$seller_email')";
$result_orders = mysqli_query($conn, $select_orders);

while ($order = mysqli_fetch_assoc($result_orders)) {
    $product_id = $order['product_id'];
    $order_date = $order['order_date'];
    $select_product = "SELECT * FROM products WHERE id = $product_id AND seller_email = '$seller_email' AND status = '1'";
    $result_product = mysqli_query($conn, $select_product);
    $product = mysqli_fetch_assoc($result_product);
    if ($product) {
        $month = date('n', strtotime($order_date));
        $monthly_earnings[$month - 1] += $product['price'] * $order['p_qty'];
    }
}
$monthly_earnings_json = json_encode($monthly_earnings);
?>

<!DOCTYPE html>
<html lang="en">
<body>
    <?php include '../../includes/dashboard_navbar.php'; ?>
    <main id="main" class="main mt-5">
    <div class="container-fluid">
        <div class="text-left fs-3 mb-3" style="border-bottom: 3px black solid;"><b>Analytics</b></div>
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-dark dropdown-toggle rounded-0" data-bs-toggle="dropdown" aria-expanded="false">
                                Select Date Range
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">This Month</a></li>
                                <li><a class="dropdown-item" href="#">This Year</a></li>
                                <li><a class="dropdown-item" href="#">Today</a></li>
                                <li><a class="dropdown-item" href="#">This Week</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="border border-dark p-3">
                            <h4><b class="fs-5">Balance</b><br>€<?php echo array_sum($monthly_earnings); ?></h4>
                            <button class="btn btn-outline-dark mt-3 rounded-0">Withdraw</button>
                            <h4 class="mt-3"><b class="fs-5">Payment Clearing</b><br>€<?php echo array_sum($monthly_earnings); ?></h4>
                            <button class="btn btn-outline-dark mt-3 rounded-0">Payment History</button>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="border border-dark p-3">
                            <h4><b class="fs-5">Earnings to Date</b><br>€<?php echo array_sum($monthly_earnings); ?></h4>
                            <button class="btn btn-outline-dark mt-3 rounded-0">Payment History</button>
                            <h4 class="mt-3"><b class="fs-5">Expenses to Date</b><br>€<?php echo array_sum($monthly_earnings); ?></h4>
                            <button class="btn btn-outline-dark mt-3 rounded-0">Expense History</button>
                        </div>
                    </div>

                    <div class="col-12 mt-3">
                        <div class="text-center fs-4"><b>Reviews</b></div>
                        <div class="border border-dark p-3">
                            <!-- Add review content here -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="text-center fs-4 mb-3"><b>Seller Statistics</b></div>
                <div class="border border-dark p-3">
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-dark dropdown-toggle rounded-0" data-bs-toggle="dropdown" aria-expanded="false">
                            Select Date Range
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">This Month</a></li>
                            <li><a class="dropdown-item" href="#">This Year</a></li>
                            <li><a class="dropdown-item" href="#">Today</a></li>
                            <li><a class="dropdown-item" href="#">This Week</a></li>
                        </ul>
                    </div>
                    <canvas id="myChart" class="mt-3"></canvas>
                </div>
            </div>
        </div>
    </div>
</main>


    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <script src="../assets/js/main.js"></script>
    
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const ctx = document.getElementById('myChart');
    const monthlyEarnings = <?php echo $monthly_earnings_json; ?>;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            datasets: [{
                label: 'Earnings',
                data: monthlyEarnings,
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>
