<?php
session_start();
include 'head.php'; 
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit;
}
include "../../includes/db_conn.php";

$user_id = $_SESSION['user_id'];
$select_orders = "SELECT * FROM orders WHERE buyer_account_id = '$user_id'";
$result_orders = mysqli_query($conn, $select_orders);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Orders</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link rel="stylesheet" href="../style2.css">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>

  </style>
</head>
<body>
<main id="main" class="main mt-5">
    <div class="pagetitle">
        <table class="table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Billing Address</th>
                    <th>Buyer Name</th>
                    <th>Buyer Email</th>
                    <th>Buyer Number</th>
                    <th>Order Date</th>
                    <th>Payment Method</th>
                    <th>Receipt (PDF)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($order = mysqli_fetch_assoc($result_orders)) {
                    $product_id = $order['product_id'];
                    $select_product = "SELECT * FROM products WHERE id = $product_id AND status = '1'";
                    $result_product = mysqli_query($conn, $select_product);
                    $product = mysqli_fetch_assoc($result_product);
                    $imagePaths = explode(',', $product['upload']);
                    $firstImagePath = isset($imagePaths[0]) ? $imagePaths[0] : '';
                    if ($product) {
                ?>
                    <tr>
                        <td><a href="../../ecommerce/product-detail.php?id=<?= $order['product_id'] ?>"><img src="../seller_dashboard/<?php echo $firstImagePath ?>" style="width: 100px;"></a></td>
                        <td ><a href="../../ecommerce/product-detail.php?id=<?= $order['product_id'] ?>"  class="text-dark" ><?php echo $product['title']; ?></a></td>
                        <td>€<?php echo $product['price']; ?></td>
                        <td><?php echo $order['p_qty']; ?></td>
                        <td><?php echo $order['billing_address']; ?></td>
                        <td><?php echo $order['buyer_name']; ?></td>
                        <td><?php echo $order['buyer_email']; ?></td>
                        <td><?php echo $order['billing_number']; ?></td>
                        <td><?php echo $order['order_date']; ?></td>
                        <td><?php echo $order['payment_method']; ?></td>
                        <td>
                            <form action="generate_pdf.php?id=<?=$product_id?>" method="post">
                                <button type="submit" class="btn btn-dark">Download PDF</button>
                            </form>
                        </td>
                    </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script>

    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

    setTimeout(function(){
        document.querySelector('.alert').style.display = 'none';
    }, 5000); // Close the alert after 5 seconds (5000 milliseconds)
</script>
</body>
</html>
