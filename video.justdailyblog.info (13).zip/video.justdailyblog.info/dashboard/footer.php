<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('#container').addClass('loaded');
                // Once the container has finished, the sidebar appears
                if ($('#container').hasClass('loaded')) {
                    // Show the sidebar
                    $('#sidebar').fadeIn();
                    // It is so that once the container is gone, the entire preloader section is deleted
                    $('#preloader').delay(800).fadeOut(400, function() {
                        $(this).remove();
                    });
                }
            }, 800);
        });
    </script>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
