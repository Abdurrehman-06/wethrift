<?php
include "head.php";

function updateCouponStatus($conn) {
    date_default_timezone_set('Asia/Karachi');
    $currentDateTime = date('Y-m-d\TH:i');
    $sql = "UPDATE coupons SET status = IF(start_date <= '$currentDateTime' AND end_date >= '$currentDateTime', 1, 0)";
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        return false;
    }
}

$repeating = false; // Define $repeating variable

if (isset($_POST['add_coupon'])) {
    $couponCode = $_POST['coupon-code'];
    $discount = $_POST['discount'];
    $startDate = $_POST['start-date'];
    $endDate = $_POST['end-date'];

    $checkSql = "SELECT * FROM coupons WHERE coupon_code = '$couponCode'";
    $checkResult = mysqli_query($conn, $checkSql);

    if (mysqli_num_rows($checkResult) > 0) {
        $repeating = true;
    } else {
        // Insert coupon if it's not repeating
        $sql = "INSERT INTO coupons (coupon_code, discount, start_date, end_date) VALUES ('$couponCode', '$discount', '$startDate', '$endDate')";
        if ($conn->query($sql) === TRUE) {
            updateCouponStatus($conn);
        }
    }
}

updateCouponStatus($conn);

$sql = "SELECT * FROM coupons";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<body>
<main id="main" class="main mt-5">
    <section id="add-coupon" class="container mt-2">
        <h2 class="text-center">Add Coupon</h2>  
        <?php if ($repeating) { echo "<div class='alert alert-danger'>Coupon Code Already Exists</div>"; } ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCouponModal">Add Coupon</button>
    </section>
    <section id="view-coupons" class="container mt-2">
        <div class="table-responsive">
            <table class="table">
    <thead>
        <tr>
            <th scope="col">Coupon Code</th>
            <th scope="col">Discount %</th>
            <th scope="col">Start Date</th>
            <th scope="col">Expiry Date</th>
            <th scope="col">Status</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['coupon_code'] . "</td>";
            echo "<td>" . $row['discount'] . "</td>";
            echo "<td>" . $row['start_date'] . "</td>";
            echo "<td>" . $row['end_date'] . "</td>";
            echo "<td><span class='" . ($row['status'] == 1 ? 'text-success' : 'text-danger') . "'>" . ($row['status'] == 1 ? 'Active' : 'Inactive') . "</span></td>";
            echo "<td><button class='btn btn-dark' href='#' data-bs-toggle='modal' data-bs-target='#editCouponModal' 
                    onclick=\"populateEditCouponModal($row[id], '$row[coupon_code]', $row[discount], '$row[start_date]', '$row[end_date]')\">
                    <i class='fa-regular fa-pen-to-square'></i> Edit
                </button></td>";
            echo "<td>";
            echo "<form action='delete_coupon.php' method='POST'>";
            echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
            echo "<button type='submit' class='btn btn-danger' onclick=\"return confirm('Are you sure you want to delete this coupon?')\"><i class='fas fa-trash-alt'></i> Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

        </div>
    </section>
</main>
<div class="modal fade" id="addCouponModal" tabindex="-1" aria-labelledby="addCouponModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCouponModalLabel">Add Coupon</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
    <form action="" method="POST" onsubmit="return validateCouponForm()">
        <div class="mb-3">
            <label for="coupon-code" class="form-label">Coupon Code</label>
            <input type="text" class="form-control" id="coupon-code" name="coupon-code" required>
            <div id="coupon-error" class="text-danger"></div>
        </div>
                        <div class="mb-3">
                            <label for="discount" class="form-label">Discount (%)</label>
                           <input type="number" min="1"  class="form-control" id="discount" name="discount" required oninput="limitTwoDigitNumber(this)">
                        </div>
                        <div class="d-flex">
                        <div class="mb-3 col-6">
                            <label for="start-date" class="form-label">Start Date</label>
                            <input type="datetime-local" class="form-control" id="start-date" name="start-date" required>
                        </div>
                        <div class="mb-3 col-6">
                            <label for="end-date" class="form-label">End Date</label>
                            <input type="datetime-local" class="form-control" id="end-date" name="end-date" required>
                        </div>
                        </div>
                        <button type="submit" id="addCouponModalBtn" class="btn btn-primary" name="add_coupon">Add Coupon</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<div class="modal fade" id="editCouponModal" tabindex="-1" aria-labelledby="editCouponModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editCouponModalLabel">Edit Coupon</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="update_coupon.php" method="POST">
                    <input type="hidden" name="id" id="editCouponId">
                    <div class="mb-3">
                        <label for="edit-coupon-code" class="form-label">Coupon Code</label>
                        <input type="text" class="form-control" id="edit-coupon-code" name="coupon-code" required pattern="[a-zA-Z0-9]+" title="Coupon code should contain only letters and numbers without spaces">
                        <div id="edit-coupon-error" class="text-danger"></div>
                    </div>

                    <div class="mb-3">
                        <label for="edit-discount" class="form-label">Discount (%)</label>
                        <input type="number" class="form-control" id="edit-discount" min="1" name="discount" required>
                    </div>
                    <div class="d-flex">
                        <div class="mb-3 col-6">
                            <label for="edit-start-date" class="form-label">Start Date</label>
                            <input type="datetime-local" class="form-control" id="edit-start-date" name="start-date" required>
                        </div>
                        <div class="mb-3 col-6">
                            <label for="edit-end-date" class="form-label">End Date</label>
                            <input type="datetime-local" class="form-control" id="edit-end-date" name="end-date" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" name="update_coupon">Update Coupon</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function populateEditCouponModal(couponId, couponCode, discount, startDate, endDate) {
        document.getElementById('editCouponId').value = couponId;
        document.getElementById('edit-coupon-code').value = couponCode;
        document.getElementById('edit-discount').value = discount;
        document.getElementById('edit-start-date').value = startDate;
        document.getElementById('edit-end-date').value = endDate;
    }
</script>
<script>
    function validateCouponForm() {
        const couponCode = document.getElementById('coupon-code').value;
        const regex = /^[a-zA-Z0-9]+$/;
        if (!regex.test(couponCode)) {
            document.getElementById('coupon-error').innerText = "Coupon code should contain only letters and numbers.";
            return false;
        }
        return true;
    }
    
     const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
     const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
        
</script>
 <script>
function limitTwoDigitNumber(input) {
    // Parse the input value as an integer
    let value = parseInt(input.value);

    // Check if the value is greater than 100
    if (value > 100) {
        // If it's greater than 100, set the input value to 100
        input.value = 100;
    }
}
</script>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<script src="../assets/js/main.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js" integrity="sha384-BCfBSZNW3NGX1Hg6P6btgQ9YTPdh2h4k/2ZRISJ2M9XlBz0ZmcY33/CbRJ6W9HsKnxYl/sB3aYjdwR9IlQdNzg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>