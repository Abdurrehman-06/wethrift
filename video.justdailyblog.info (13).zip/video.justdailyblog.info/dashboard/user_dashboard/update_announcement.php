<?php
session_start();
include "../../includes/db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])) {
    $announcement_id = $_GET['id'];

    // Validate and sanitize input
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $start_time = mysqli_real_escape_string($conn, $_POST['start_time']);
    $end_time = mysqli_real_escape_string($conn, $_POST['end_time']);
    $target_audience = mysqli_real_escape_string($conn, $_POST['target_audience']);

    // Update announcement in the database
    $sql = "UPDATE announcements SET content='$content', start_time='$start_time', end_time='$end_time', target_audience='$target_audience' WHERE id=$announcement_id";

    if (mysqli_query($conn, $sql)) {
        // Redirect back to the page displaying all announcements
        header("Location: announcements.php");
        exit;
    } else {
        echo "Error updating announcement: " . mysqli_error($conn);
    }
} else {
    // Redirect to an error page if accessed directly without proper data
    header("Location: error.php");
    exit;
}

// Close database connection
mysqli_close($conn);
?>
