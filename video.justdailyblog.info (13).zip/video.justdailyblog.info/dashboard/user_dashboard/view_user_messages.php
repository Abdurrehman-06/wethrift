<?php
include '../../includes/db_conn.php';
include "head.php";

// Check if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['reply_message']) && isset($_POST['user_id'])){
        // Escape user inputs to prevent SQL injection
        $reply_message = mysqli_real_escape_string($conn, $_POST['reply_message']);
        $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);

        // Prepare and execute the SQL query to insert the message
        $insert_query = "INSERT INTO messages (user_id, username, message, is_admin_reply) VALUES ('$user_id', 'Admin', '$reply_message', 1)";
        if (mysqli_query($conn, $insert_query)) {
            exit(json_encode(['success' => true])); // Send success response
        } else {
            exit(json_encode(['error' => 'Error sending message'])); // Send error response
        }
    } else {
        exit(json_encode(['error' => 'Form submission incomplete'])); // Send error response
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous">
    <link rel="stylesheet" href="chat.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .messages {
            list-style-type: none;
            max-height:500px;
            margin: 0;
            padding: 0;
            overflow-y: auto;
        }
        .messages li {
            margin-bottom: 10px;
            overflow: auto;
            clear: both;
            margin-right: 10px;
        }
        .messages li img {
            width: 50px;
            border-radius: 50%;
            float: left;
            margin-right: 10px;
        }
        .messages li p {
            background: #f9f9f9;
            padding: 10px;
            border-radius: 10px;
            display: inline-block;
            word-wrap: break-word;
        }
        .messages li.admin-sent img {
            float: right;
            margin-left: 10px;
        }
        .messages li.admin-sent p {
            background: #007bff;
            float: right;
            color: white;
        }
        .messages li.user-sent img {
            float: left;
            margin-right: 10px;
        }
        .messages li.user-sent p {
            background: #007bff;
            float: left;
            color: white;
        }
        .reply-form {
            margin-top: 20px;
            display: flex;
            align-items: center;
        }
        .reply-form input[type="text"] {
            width:90%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }
        .reply-form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<main id="main" class="main mt-5">
<div id="frame">
    <div class="content">
        <div class="messages">
            <ul id="message-container" data-user-id="<?php echo isset($_GET['user_id']) ? $_GET['user_id'] : ''; ?>">
                <?php
                session_start();
                if (!isset($_SESSION['user_id'])) {
                    header("Location:../buyer_login.php");
                    exit;
                }
                include "../includes/db_conn.php";
                if (isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                    $sql = "SELECT * FROM messages WHERE user_id = $user_id ORDER BY id ASC";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        if (mysqli_num_rows($result) > 0) {
                            $messages = array();
                            while ($row = mysqli_fetch_assoc($result)) {
                                $messages[] = $row;
                            }
                            // Display messages
                            foreach ($messages as $message) {
                                $css_class = $message['is_admin_reply'] ? 'admin-sent' : 'user-sent';
                                ?>
                                <li class="<?php echo $css_class; ?>">
                                    <img src="<?php echo $message['is_admin_reply'] ? 'http://emilcarlsson.se/assets/mikeross.png' : 'http://emilcarlsson.se/assets/harveyspecter.png'; ?>" alt="" />
                                    <p><?php echo $message["message"]; ?></p>
                                </li>
                                <?php
                            }
                        } else {
                            echo "<p>No messages yet.</p>";
                        }
                    } else {
                        echo "<p>Error: " . mysqli_error($conn) . "</p>";
                    }
                    mysqli_close($conn);
                } else {
                    echo "<p>User not logged in.</p>";
                }
                ?>
            </ul>
        </div>
        <!-- Reply form -->
        <div class="d-flex" id="form-mar">
            <div class="col-10">
                <form class="reply-form" id="admin-reply-form">
                    <input type="text" name="reply_message" class="form-control" placeholder="Type your reply..." required>
                    <input type="hidden" name="user_id" value="<?php echo isset($_GET['user_id']) ? $_GET['user_id'] : ''; ?>">
                </form>
            </div>
            <div class="col-2 mt-4" >
                <button type="submit" form="admin-reply-form" class="btn btn-primary w-100">Reply</button>
            </div>
        </div>

    </div>
</div>
</main>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Function to scroll message container to bottom
    function scrollToBottom() {
        var messageContainer = $('.messages');
        messageContainer.scrollTop(messageContainer.prop("scrollHeight"));
    }

    // Function to fetch and display messages
    function fetchMessages() {
        var userId = $('#message-container').data('user-id');
        $.ajax({
            type: "GET",
            url: "ajax_messages.php",
            data: { user_id: userId }, // Include user_id parameter in the request
            dataType: 'json',
            success: function(response) {
                $('#message-container').empty(); // Clear existing messages
                response.forEach(function(message) {
                    var cssClass = message['is_admin_reply'] ? 'admin-sent' : 'user-sent';
                    var imageUrl = message['is_admin_reply'] ? 'http://emilcarlsson.se/assets/mikeross.png' : 'http://emilcarlsson.se/assets/harveyspecter.png';
                    var messageHtml = '<li class="' + cssClass + '">';
                    messageHtml += '<img src="' + imageUrl + '" alt="" />';
                    messageHtml += '<p>' + message["message"] + '</p>';
                    messageHtml += '</li>';
                    $('#message-container').append(messageHtml);
                });
                scrollToBottom();
            },
            error: function(xhr, status, error) {
                console.error('Error fetching messages: ' + error);
            }
        });
    }

    fetchMessages();
    setInterval(fetchMessages, 5000);

    $('#admin-reply-form').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            type: "POST",
            url: "view_user_messages.php",
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.hasOwnProperty('error')) {
                    console.error('Error sending message: ' + response.error);
                } else if (response.hasOwnProperty('success')) {
                    // Clear input field after sending message
                    $('#admin-reply-form input[name="reply_message"]').val('');
                    // Fetch messages immediately after sending a reply
                    fetchMessages();
                }
            },
            error: function(xhr, status, error) {
                console.error('Error sending message: ' + error);
            }
        });
    });
});

</script>
</body>
</html>