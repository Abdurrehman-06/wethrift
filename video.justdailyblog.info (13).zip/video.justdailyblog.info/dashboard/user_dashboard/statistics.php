<?php
session_start();
include "head.php";
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}

$sqlStatus4 = "SELECT COUNT(*) AS count FROM users WHERE status = 4";
$resultStatus4 = $conn->query($sqlStatus4);
$rowStatus4 = $resultStatus4->fetch_assoc();
$countStatus4 = $rowStatus4['count'];

$sqlStatus3 = "SELECT COUNT(*) AS count FROM users WHERE status = 3";
$resultStatus3 = $conn->query($sqlStatus3);
$rowStatus3 = $resultStatus3->fetch_assoc();
$countStatus3 = $rowStatus3['count'];

$sqlStatus1 = "SELECT COUNT(*) AS count FROM users WHERE status = 1";
$resultStatus1 = $conn->query($sqlStatus1);
$rowStatus1 = $resultStatus1->fetch_assoc();
$countStatus1 = $rowStatus1['count'];

$sqlStatus2 = "SELECT COUNT(*) AS count FROM users WHERE status = 2";
$resultStatus2 = $conn->query($sqlStatus2);
$rowStatus2 = $resultStatus2->fetch_assoc();
$countStatus2 = $rowStatus2['count'];

$sqlStatus0 = "SELECT COUNT(*) AS count FROM users WHERE status = 0";
$resultStatus0 = $conn->query($sqlStatus0);
$rowStatus0 = $resultStatus0->fetch_assoc();
$countStatus0 = $rowStatus0['count'];

$productsqlStatus1 = "SELECT COUNT(*) AS count FROM products WHERE status = 1"; // Updated SQL query
$productresultStatus1 = $conn->query($productsqlStatus1);
$productrowStatus1 = $productresultStatus1->fetch_assoc();
$productcountStatus1 = $productrowStatus1['count']; // Updated variable name

$productsqlAll = "SELECT * FROM products"; // SQL query to fetch all products
$productresultAll = $conn->query($productsqlAll);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<style>
  .card {
    float: left;
    margin: 0px 10px;
    text-align: center;
    padding: 20px;
    transition: background-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.card:hover {
    background-color: black;
    color: white;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}
    
</style>

<body>
<main id="main" class="main mt-5">
  <div class="row">
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Users</h3>
      <p><?php echo $countStatus4; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Sellers</h3>
      <p><?php echo $countStatus3; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Admins</h3>
      <p><?php echo $countStatus1; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Unverified Sellers</h3>
      <p><?php echo $countStatus2; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Unverified Users</h3>
      <p><?php echo $countStatus0; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Unverified Products</h3>
      <p><?php echo $countStatus0; ?></p>
    </div>
    <div class="col-lg-3 col-md-3 card mt-3">
      <h3>Activated Products</h3>
      <p><?php echo $productcountStatus1; ?></p>
    </div>
  </div>
</main>


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var currentPageUrl = window.location.pathname;

    var sidebarLinks = document.querySelectorAll("#sidebar-nav .nav-item .nav-link");

    sidebarLinks.forEach(function(link) {
        if (link.getAttribute("href") === currentPageUrl) {
            link.classList.add("active");
        }
    });
});

    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
</script>
<script src="../assets/js/main.js"></script>
<!-- Vendor JS Files -->
<script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/chart.js/chart.umd.js"></script>
<script src="assets/vendor/echarts/echarts.min.js"></script>
<script src="assets/vendor/quill/quill.min.js"></script>
<script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="assets/vendor/tinymce/tinymce.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<!-- Template Main JS File -->
<script src="../assets/js/main.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"
        integrity="sha512-BCfBSZNW3NGX1Hg6P6btgQ9YTPdh2h4k/2ZRISJ2M9XlBz0ZmcY33/CbRJ6W9HsKnxYl/sB3aYjdwR9IlQdNzg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>

</html>

