<?php 
include "head.php";
    if (isset($_POST['submit'])) {
        $categories =  $_POST['categories'];
        $sql = "SELECT * FROM `categories` where categories = '$categories' ";
        $already = mysqli_query($conn,$sql);
        $rows = mysqli_num_rows($already);
        if ($rows > 0) {
            echo "<script> alert('Category already exists')</script>";
        } else {
            $insert = "INSERT INTO `categories` (`categories`) VALUES ('$categories')";
            $run = mysqli_query($conn,$insert);
            if($run){
            } else {
                echo "<script> alert('Something went wrong')</script>";
            }
        }
    }
      
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST['submit_sub'])) {
       
        $categories_id = $_POST['categories_id'];
        $sub_categories =  $_POST['sub_categories'];

   
        $insert_query = "INSERT INTO `subcategories` (`categories_id` , `sub_categories`) VALUES ('$categories_id', '$sub_categories')";
        $result = mysqli_query($conn, $insert_query);
        
        if ($result) {
            echo "";
        } else {
            echo "okkkk";
        }
    } else {
        echo "Please fill all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
       tr {
            border-botton: 0px!important;
            
        }
    

    </style>
</head>
<body>
    <main id="main" class="main mt-5">
        <h3 class="text-center">Add Category</h3>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form-group d-flex justify-content-center">
                <input class="form-control rounded-0" style="width:250px;" type="text" name="categories" maxlength="10" required>
                <input class="btn bg-dark text-white rounded-0" value="Add Category" type="submit" name="submit">
            </div>
        </form>
        <div class="col-lg-4 col-md-6 col-sm-12">
        <table class="table mt-3">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category Name</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php
                $select = "SELECT * FROM `categories`";
                $run = mysqli_query($conn, $select);
                $count = 1;
                while ($row = mysqli_fetch_assoc($run)) {
                    $category_id = $row['id'];
                    $category_name = $row['categories'];
                ?>
                    <tr>
                        <th scope="row"><?= $count ?></th>
                        <td ><?= $category_name ?></td>
                        <!--<td><a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateModal<?=$category_id;?>">Update</a></td>-->
                        <td><a href="#" class="btn btn-primary update-category" data-bs-toggle="modal" data-bs-target="#updateModal<?=$category_id;?>"><i class="fa-regular fa-pen-to-square"></i> Update</a></td>
                        <td>
    <form action="delete_category.php" method="POST">
        <input type="hidden" name="id" value="<?= $category_id ?>">
        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this category?')">
            <i class="fas fa-trash-alt"></i>
        </button>
    </form>
</td>

                    </tr>
                    <!-- Update Modal -->
<div class="modal fade" id="updateModal<?= $category_id ?>" tabindex="-1" aria-labelledby="updateModalLabel<?= $category_id ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateModalLabel<?= $category_id ?>">Update Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
<form id="updateForm" action="update_category.php" method="POST">
    <input type="hidden" id="categoryId<?= $category_id ?>" name="categoryId" value="<?= $category_id ?>">
    <div class="mb-3">
        <label for="categoryName<?= $category_id ?>" class="form-label">Category Name</label>
        <input type="text" class="form-control" id="categoryName<?= $category_id ?>" maxlength="10" name="categoryName" value="<?= $category_name ?>">
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-regular fa-pen-to-square"></i>Update</button>
</form>
            </div>
        </div>
    </div>
</div>
                <?php
                    $count++;
                }
                ?>
            </tbody>
        </table>
        </div>
        <h3>Add Subcategory</h3>
        <form method="POST">
            <div class="col-md-12">
                <div class="col-md-5 d-flex">
                    <label>Select Category</label>
    <select name="categories_id" style="width:20%;" class="form-control col-md-4 col-lg-2">
        <?php 
        $categories_query = "SELECT * FROM `categories`";
        $categories_result = mysqli_query($conn, $categories_query);
        if ($categories_result && mysqli_num_rows($categories_result) > 0) {
            while ($category = mysqli_fetch_assoc($categories_result)) {
                ?>
                <option value="<?= $category['id']; ?>"><?= $category['categories']; ?></option>
                <?php 
            }
        } else {
            echo "No categories available";
        }
        ?>
    </select>
    </div>
    <div class="row align-items-end">
    <div class="col-md-5 col-lg-3 col-sm-6 col-6 form-group">
        <label>Subcategories</label>
        <input type="text" class="form-control col-lg-3" maxlength="10" name="sub_categories">
    </div>
  
 
    <button type="submit" name="submit_sub" class="col-md-1 btn btn-primary " style="height:40px; width:100px;">Add</button>
       
      </div> </div>
</form>
<div class="col-lg-6 col-md-8 col-sm-12">
        <table class="table mt-3">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Subcategory Name</th>
                    <th>Category</th>
                </tr>
            </thead>
            <tbody>
        <?php
    $select = "SELECT * FROM `subcategories`";
    $run = mysqli_query($conn, $select);
    $count = 1;
    while ($row = mysqli_fetch_assoc($run)) {
        $subcategories_id = $row['id'];
        $categories_id = $row['categories_id'];
        $sub_categories = $row['sub_categories'];
        
        $select_cat = "SELECT * FROM `categories` WHERE id = '$categories_id'";
        $query = mysqli_query($conn, $select_cat); 
        $row_cat = mysqli_fetch_assoc($query);
        $categories = $row_cat['categories'];
?>
        <tr>
            <th scope="row"><?= $count ?></th>
            <td><?= $sub_categories ?></td>
            <td><?= $categories ?></td>
            <td><a href="#" class="btn btn-primary update-category" data-bs-toggle="modal" data-bs-target="#updateModal<?= $subcategories_id;?>"><i class="fa-regular fa-pen-to-square"></i> Update</a></td>
<td>
    <form action="delete_subcategory.php" method="POST">
        <input type="hidden" name="id" value="<?= $subcategories_id ?>">
        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this subcategory?')">
            <i class="fas fa-trash-alt"></i>
        </button>
    </form>
</td>

        </tr>
        <div class="modal fade" id="updateModal<?= $subcategories_id ?>" tabindex="-1" aria-labelledby="updateModalLabel<?= $subcategories_id ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateModalLabel<?= $subcategories_id ?>">Update Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
<form id="updateForm" action="update_subcategory.php" method="POST">
    <input type="hidden" id="categoryId<?= $subcategories_id ?>" name="categoryId" value="<?= $subcategories_id ?>">
    <div class="mb-3">
        <label for="categoryName<?= $subcategories_id ?>" class="form-label">Category Name</label>
        <input type="text" class="form-control" id="categoryName<?= $subcategories_id ?>" name="categoryName" maxlength="10" value="<?= $sub_categories ?>">
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
</form>
            </div>
        </div>
    </div>
</div>
<?php
        $count++;
    }
?>

                
            </tbody>
        </table>
        </div>
    </main>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <!-- Scripts -->


    <script>
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    </script>
    <script src="../assets/js/main.js"></script>
      <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js" integrity="sha512-BCfBSZNW3NGX1Hg6P6btgQ9YTPdh2h4k/2ZRISJ2M9XlBz0ZmcY33/CbRJ6W9HsKnxYl/sB3aYjdwR9IlQdNzg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</body>

</html>
