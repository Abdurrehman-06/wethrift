<?php
// Establish database connection
include "../../includes/db_conn.php";

if (isset($_POST['update'])) {
    // Retrieve form data
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $title = mysqli_real_escape_string($conn, $_POST["title"]);
    $categories_id = mysqli_real_escape_string($conn, $_POST["categories_id"]);
    $price = mysqli_real_escape_string($conn, $_POST["price"]);
    $discount = mysqli_real_escape_string($conn, $_POST["discount"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);

    // Handle sizes
    if (isset($_POST["size"])) {
        $size = mysqli_real_escape_string($conn, implode(", ", $_POST["size"]));
    } else {
        // If no new sizes are selected, fetch existing sizes from the database
        $sql_sizes = "SELECT size FROM products WHERE id=?";
        $stmt_sizes = mysqli_prepare($conn, $sql_sizes);
        mysqli_stmt_bind_param($stmt_sizes, "i", $id);
        mysqli_stmt_execute($stmt_sizes);
        mysqli_stmt_bind_result($stmt_sizes, $existing_sizes);
        mysqli_stmt_fetch($stmt_sizes);
        mysqli_stmt_close($stmt_sizes);

        $size = $existing_sizes;
    }

    // Handle file upload if a new file is chosen
    if ($_FILES["upload"]["name"] != '') {
        $uploadDir = "uploads/";
        $uploadFile = $uploadDir . basename($_FILES["upload"]["name"]);
        move_uploaded_file($_FILES["upload"]["tmp_name"], $uploadFile);
    } else {
        // If no new file is selected, keep the existing file
        $sql = "SELECT upload FROM products WHERE id=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $uploadFile);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    }

    // Update data in database using prepared statement
    $sql_update = "UPDATE products SET 
            title=?, 
            categories_id=?, 
            size=?, 
            price=?, 
            discount=?, 
            description=?, 
            upload=? 
            WHERE id=?";
    
    $stmt_update = mysqli_prepare($conn, $sql_update);
    mysqli_stmt_bind_param($stmt_update, "sssssssi", $title, $categories_id, $size, $price, $discount, $description, $uploadFile, $id);
    
    if(mysqli_stmt_execute($stmt_update)) {
        header("Location: products.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt_update);
}
?>
