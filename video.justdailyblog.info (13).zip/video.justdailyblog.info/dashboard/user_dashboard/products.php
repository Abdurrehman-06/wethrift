<?php
include "head.php";
$select_query = "SELECT * FROM users WHERE status IN (2, 3)";
$sellers_result = mysqli_query($conn, $select_query);
?>
<!DOCTYPE html>
<html lang="en">
<style>
        .active-button {
            border-color: green;
            background-color: transparent;
            color: green;
            padding: 2px 10px;
        }
        .inactive-button {
            border-color: red;
            background-color: transparent;
            padding: 2px 10px;
            color: red;
        }

        /* Loader styles */
        #loader {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 6px solid #f3f3f3;
            border-radius: 50%;
            border-top: 6px solid #3498db;
            width: 40px;
            height: 40px;
            -webkit-animation: spin 2s linear infinite;
            animation: spin 2s linear infinite;
        }

        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    .active-button {
      border-color: red;
      background-color: transparent;
      color: red;
      padding: 2px 10px;
    }

    .inactive-button {
      border-color: green;
      background-color: transparent;
      padding: 2px 10px;
      color: green;
    }

    .active-button:hover {
      border-color: green;
      background-color: green;
      color: white;
      padding: 2px 10px;
    }

    .inactive-button:hover {
      border-color: red;
      background-color: red;
      padding: 2px 10px;
      color: white;
    }
  </style>
</head>

<body>

<div id="loader"></div>
  <main id="main" class="main mt-5">
    <?php if(isset($_GET['error'])){ ?>
    <div class="alert alert-danger" role="alert">
      <?php echo $_GET['error']; ?>
    </div>
    <?php } ?>
    <?php if(isset($_GET['success'])){ ?>
    <div class="alert alert-success" role="alert">
      <?php echo $_GET['success']; ?>
    </div>
    <?php } ?>
    <?php
    $query = "SELECT * FROM `products`";
    $data = mysqli_query($conn, $query);

    if(mysqli_num_rows($data) > 0) {
      $rowNumber = 1;
    ?>
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Product Title</th>
          <th>Seller Username</th>
          <th>Seller details</th>
          <th>Price</th>
          <th>Action</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        <?php
          while ($result = mysqli_fetch_assoc($data)) {
            $id = $result['id']; 
            $email= $result['seller_email'];
            $select_cat = "SELECT * FROM `users` WHERE email = '$email'";
            $run = mysqli_query($conn, $select_cat);
            $results = mysqli_fetch_assoc($run);
            $imagePaths = explode(',', $result['upload']);
            $firstImagePath = isset($imagePaths[0]) ? $imagePaths[0] : '';
        ?>
        <tr>
          <td><?= $rowNumber++  ?> </td>
          <td><a href="../../ecommerce/product-detail.php?id=<?= $id ?>"><img src='../seller_dashboard/<?= $firstImagePath ?>' width='100px' height='auto'></a></td>
          <td><a style="text-decoration:none;" href="../../ecommerce/product-detail.php?id=<?= $id ?>" class="text-dark"><?= $result['title'] ?></a></td>
        
          <td><?= $results['username'] ?></td>
         <td><?php echo "<button class='btn btn-primary view-details' data-seller-id='" . $results['id'] . "'>Details</button>"; ?></td>
          
          <td><?= $result['price'] ?></td>
          <td>
            <button class="btn toggle-product-status btn py-1 <?php echo $result['status'] == 1 ? 'active-button' : 'inactive-button'; ?>" 
              data-product-id="<?= $result['id'] ?>" 
              data-current-status="<?= $result['status'] ?>">
              <?= $result['status'] == 1 ? 'Deactivate' : 'Verify Product' ?>
            </button>
          </td>
<td>
    <form action='admin_delete_products.php' method='POST'>
        <input type='hidden' name='id' value='<?= $id ?>'>
        <button type='submit' class='btn btn-danger' name='delete_product'>
            <i class='fas fa-trash-alt'></i> Delete
        </button>
    </form>
</td>

        </tr>
        <?php
          }
        ?>
      </tbody>
    </table>
    <?php
    } else {
      echo "<script>alert('Table has no records')</script>";
    }
    ?>
    
    <?php if(mysqli_num_rows($sellers_result) > 0) { ?>
<div class="modal fade" id="sellerDetailsModal" tabindex="-1" aria-labelledby="sellerDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sellerDetailsModalLabel">Seller Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="sellerDetailsContent">
                <!-- Seller details will be loaded here -->
            </div>
        </div>
    </div>
</div>
<?php } ?>
    
  </main>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.toggle-product-status').click(function() {
        const button = $(this);
        const productId = button.data('product-id');
        const currentStatus = parseInt(button.data('current-status'));
        const newStatus = currentStatus === 1 ? 0 : 1;

        // Show loader
        $('#loader').show();

        // AJAX request to update product status
        $.ajax({
            type: 'POST',
            url: 'update_product_status.php',
            data: {
                productId: productId,
                newStatus: newStatus
            },
            success: function(response) {
                console.log(response); // Log response for debugging
                if (response === "Success") {
                    // Hide loader
                    $('#loader').hide();

                    // Update button text and data attribute
                    const buttonText = newStatus === 1 ? 'Deactivate' : 'Activate';
                    button.text(buttonText);
                    button.data('current-status', newStatus);

                    // Update button class based on new status
                    const buttonClass = newStatus === 1 ? 'active-button' : 'inactive-button';
                    button.removeClass('active-button inactive-button').addClass(buttonClass);
                } else {
                    console.error('Error updating product status:', response);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error updating product status:', error);
            }
        });
    });
});

</script>
 <script>
    $(document).ready(function() {
        $('.view-details').click(function() {
            const sellerId = $(this).data('seller-id');
            $.ajax({
                type: 'POST',
                url: 'fetch_seller_details.php',
                data: {
                    sellerId: sellerId
                },
                success: function(response) {
                    $('#sellerDetailsContent').html(response);
                    $('#sellerDetailsModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching seller details:', error);
                }
            });
        });
    });
    </script>
</body>

</html>
