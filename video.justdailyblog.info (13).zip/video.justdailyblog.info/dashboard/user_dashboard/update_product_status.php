<?php
session_start();
include "../../includes/db_conn.php";
require '../../smtp/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["productId"]) && isset($_POST["newStatus"])) {
        $productId = mysqli_real_escape_string($conn, $_POST["productId"]);
        $newStatus = mysqli_real_escape_string($conn, $_POST["newStatus"]);
        
        // Update product status
        $updateQuery = "UPDATE products SET status = '$newStatus' WHERE id = '$productId'";
        if (mysqli_query($conn, $updateQuery)) {
            // Send email notification
            if ($newStatus == 1) {
                sendApprovalEmail($productId, $conn);
            } elseif ($newStatus == 0) {
                sendDeactivationEmail($productId, $conn);
            }
            echo "Success"; // Send success response
        } else {
            echo "Error updating product status: " . mysqli_error($conn); 
        }
    } else {
        echo "Missing parameters"; 
    }
} else {
    echo "Invalid request"; 
}

function sendApprovalEmail($productId, $conn) {
    // Fetch product details
    $productQuery = "SELECT * FROM products WHERE id = '$productId'";
    $productResult = mysqli_query($conn, $productQuery);
    if ($productResult && mysqli_num_rows($productResult) > 0) {
        $productData = mysqli_fetch_assoc($productResult);
        $productName = $productData['title'];
        $productOwnerEmail = $productData['seller_email']; // Corrected the column name

        // Send approval email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            // Configure SMTP settings
            $mail->Host = "premium55.web-hosting.com";
            $mail->SMTPAuth = true;
            $mail->Username = "info@form.justdailyblog.info";
            $mail->Password = "xnz;(III.dXJ";
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom("info@form.justdailyblog.info");
            $mail->addAddress($productOwnerEmail);

            $mail->isHTML(true);
            $mail->Subject = 'Product Approved';
            $mail->Body = "Congratulations! Your product '$productName' has been approved by the admin.";

            // Send email
            $mail->send();
        } catch (Exception $e) {
            echo "Error sending approval email: {$mail->ErrorInfo}";
        }
    }
}

// Function to send deactivation email
function sendDeactivationEmail($productId, $conn) {
    // Fetch product details
    $productQuery = "SELECT * FROM products WHERE id = '$productId'";
    $productResult = mysqli_query($conn, $productQuery);
    if ($productResult && mysqli_num_rows($productResult) > 0) {
        $productData = mysqli_fetch_assoc($productResult);
        $productName = $productData['title']; // Corrected the column name
        $productOwnerEmail = $productData['seller_email']; // Corrected the column name

        // Send deactivation email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = "premium55.web-hosting.com";
            $mail->SMTPAuth = true;
            $mail->Username = "info@form.justdailyblog.info";
            $mail->Password = "xnz;(III.dXJ";
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom("info@form.justdailyblog.info");
            $mail->addAddress($productOwnerEmail);
            $mail->isHTML(true);
            $mail->Subject = 'Product Deactivated';
            $mail->Body = "Your product '$productName' has been deactivated by the admin.";

            // Send email
            $mail->send();
        } catch (Exception $e) {
            echo "Error sending deactivation email: {$mail->ErrorInfo}";
        }
    }
}
?>
