<?php
session_start();
include "../../includes/db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $announcement_id = $_POST['id'];

    // Delete announcement from the database
    $sql = "DELETE FROM announcements WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $announcement_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Redirect back to the page displaying all announcements
        header("Location: announcements.php");
        exit();
    } else {
        echo "Error deleting announcement: " . mysqli_error($conn);
    }
} else {
    // Redirect to an error page if accessed directly without proper data
    header("Location: error.php");
    exit();
}

// Close database connection
mysqli_close($conn);
?>
