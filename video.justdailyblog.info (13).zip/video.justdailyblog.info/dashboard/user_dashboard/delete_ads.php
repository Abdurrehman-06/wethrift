<?php
// Include database connection
include "../../includes/db_conn.php";

// Check if the ID is provided via GET request
if(isset($_GET['id'])) {
    // Sanitize the ID parameter
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Prepare a delete query
    $delete_query = "DELETE FROM adspace WHERE id = '$id'";

    // Execute the delete query
    if(mysqli_query($conn, $delete_query)) {
        // If deletion is successful, redirect back to the page where ads are displayed
        header("Location: announcements.php");
        exit();
    } else {
        // If deletion fails, display an error message
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If no ID is provided, redirect back to the page where ads are displayed
    header("Location: display_ads.php");
    exit();
}
?>
