<?php
session_start();
include "../../includes/db_conn.php";
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $user_id = mysqli_real_escape_string($conn, $_GET['id']);
    $sql = "DELETE FROM users WHERE id = '$user_id'";
    $result = mysqli_query($conn, $sql);
    if($result) {
        header("Location: users.php?success=User deleted successfully.");
        exit();
    } else {
        header("Location: users.php?error=Error deleting user.");
        exit();
    }
} else {
    header("Location: users.php?error=User ID not provided.");
    exit();
}
?>
