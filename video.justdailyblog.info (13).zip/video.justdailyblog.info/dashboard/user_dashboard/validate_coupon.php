<?php
include "head.php";
$couponCode = $_POST['coupon_code'];
$response = array();
$checkSql = "SELECT * FROM coupons WHERE coupon_code = ?";
$stmt = $conn->prepare($checkSql);
$stmt->bind_param('s', $couponCode);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $response['error'] = true;
    $response['message'] = "Coupon code already exists.";
} else {
    // Coupon code is valid
    $response['error'] = false;
    $response['message'] = "Coupon code is valid.";
}

// Send JSON response
echo json_encode($response);
?>
