<?php
session_start();
include "head.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" >
        <style>
        .active-button {
            border-color: red;
            background-color: transparent;
            color: red;
            padding: 2px 10px;
        }
        .inactive-button {
            border-color: green;
            background-color: transparent;
            padding: 2px 10px;
            color: green;
        }

        /* Loader styles */
        #loader {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 6px solid #f3f3f3;
            border-radius: 50%;
            border-top: 6px solid #3498db;
            width: 40px;
            height: 40px;
            -webkit-animation: spin 2s linear infinite;
            animation: spin 2s linear infinite;
        }

        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <?php
    $sql = "SELECT * FROM users WHERE status IN (0, 4)";
    $result = mysqli_query($conn, $sql);
    ?>
    <div id="loader"></div>
    <main id="main" class="main mt-5">
        <h3 class="text-center">Users</h3>
        <?php if(isset($_GET['error'])){ ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $_GET['error']; ?>
            </div>
        <?php } ?>

        <!-- Success message -->
        <?php if(isset($_GET['success'])){ ?>
            <div class="alert alert-success" role="alert">
                <?php echo $_GET['success']; ?>
            </div> <?php } ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Username</th>
                    <th scope="col">Birthdate</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Email</th>
                    <th scope="col">Street Address</th>
                    <th scope="col">Delete</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    $user_id = $row['id'];
                    $username = $row['username'];
                    $birthdate = $row['birthdate'];
                    $phone_number = $row['phone_number'];
                    $email = $row['email'];
                    $street_address = $row['street_address'];
                ?>
                    <tr>
                        <th scope="row"><?= $count ?></th>
                        <td><?= $username ?></td>
                        <td><?= $birthdate ?></td>
                        <td><?= $phone_number ?></td>
                        <td><?= $email ?></td>
                        <td><?= $street_address ?></td>
                        <td><form method="post" action="delete_user.php?id=<?= $user_id ?>">
    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')" data-bs-toggle="tooltip" title="Delete User">
        <i class='fas fa-trash-alt'></i> Delete
    </button>
</form>
</td>
<td>
    <button class="toggle-button <?= ($row['status'] == 0 ? 'inactive-button' : 'active-button') ?>" data-user-id="<?= $user_id ?>" data-current-status="<?= $row['status'] ?>">
        <?= ($row['status'] == 0 ? 'Verify' : 'Deactivate') ?>
    </button>
</td>  
                    </tr>
                <?php
                    $count++;
                }
                ?>
            </tbody>
        </table>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function() {
    $('.toggle-button').click(function() {
        const userId = $(this).data('user-id');
        const currentStatus = parseInt($(this).data('current-status'));
        const newStatus = currentStatus === 4 ? 0 : 4;
        $('#loader').show();
        $.ajax({
            type: 'POST',
            url: 'update_user_status.php',
            data: {
                user_id: userId, // Corrected to match the key name used in PHP
                newStatus: newStatus,
                currentStatus: currentStatus // Pass current status for comparison in PHP
            },
            success: function(response) {
                $('#loader').hide();
                location.reload();
            },
            error: function(xhr, status, error) {
                // Hide loader
                $('#loader').hide();
                console.error('Error updating User status:', error);
            }
        });
    });
});

    </script>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
</body>
</html>
