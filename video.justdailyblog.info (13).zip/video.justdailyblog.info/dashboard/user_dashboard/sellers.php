<?php
include "head.php";
$select_query = "SELECT * FROM users WHERE status IN (2, 3)";
$sellers_result = mysqli_query($conn, $select_query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        .active-button {
            border-color: green;
            background-color: transparent;
            color: green;
            padding: 2px 10px;
        }
        .inactive-button {
            border-color: red;
            background-color: transparent;
            padding: 2px 10px;
            color: red;
        }

        /* Loader styles */
        #loader {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 6px solid #f3f3f3;
            border-radius: 50%;
            border-top: 6px solid #3498db;
            width: 40px;
            height: 40px;
            -webkit-animation: spin 2s linear infinite;
            animation: spin 2s linear infinite;
        }

        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>

<body>
    <div id="loader"></div>
    <main id="main" class="main mt-5">
        <h1>Sellers</h1>
        <?php if(mysqli_num_rows($sellers_result) > 0) { ?>
<div class="modal fade" id="sellerDetailsModal" tabindex="-1" aria-labelledby="sellerDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sellerDetailsModalLabel">Seller Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="sellerDetailsContent">
                <!-- Seller details will be loaded here -->
            </div>
        </div>
    </div>
</div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Company Name</th>
                    <th>Join Date</th>
                    <th>Status</th>
                    <th>Details</th>
                    <th>Action</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($seller_row = mysqli_fetch_assoc($sellers_result)) {
                    echo "<tr>";
                    echo "<td>" . $seller_row['username'] . "</td>";
                    echo "<td>" . $seller_row['company_name'] . "</td>";
                    echo "<td>" . $seller_row['join_date'] . "</td>";
                    echo "<td style='color: " . ($seller_row['status'] == 3 ? 'green' : 'red') . "'>" . ($seller_row['status'] == 3 ? 'Active' : 'Not Activated') . "</td>";
                    echo "<td> <button class='btn btn-primary view-details' data-seller-id='" . $seller_row['id'] . "'>Details</button></td>";
                    echo "<td>";
                    echo '<button class="toggle-button ' . ($seller_row['status'] == 3 ? 'inactive-button' : 'active-button') . '" data-seller-id="' . $seller_row['id'] . '" data-current-status="' . $seller_row['status'] . '">' . ($seller_row['status'] == 3 ? 'De-Activate Account' : 'Activate Account') . '</button>';
echo "</td>";
echo "<td style='color:red !important;'>";
echo "<form action='delete_seller.php' method='POST'>";
echo "<input type='hidden' name='id' value='" . $seller_row['id'] . "'>";
echo "<button type='submit' class='btn btn-danger' name='delete_seller'><i class='fas fa-trash-alt'></i> Delete</button>";
echo "</form>";
echo "</td>";
echo "</tr>";

                }
                ?>
            </tbody>
        </table>
        <?php
} else {
echo '<div class="alert alert-danger" role="alert">';
echo "No sellers found.";
echo '</div>';
}
?>
    </main>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <script src="../assets/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $('.view-details').click(function() {
            const sellerId = $(this).data('seller-id');

            // AJAX request to fetch seller details
            $.ajax({
                type: 'POST',
                url: 'fetch_seller_details.php',
                data: {
                    sellerId: sellerId
                },
                success: function(response) {
                    // Populate modal with seller details
                    $('#sellerDetailsContent').html(response);
                    // Show the modal
                    $('#sellerDetailsModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching seller details:', error);
                }
            });
        });
    });
        $(document).ready(function() {
            $('.toggle-button').click(function() {
                const sellerId = $(this).data('seller-id');
                const currentStatus = parseInt($(this).data('current-status'));
                const newStatus = currentStatus === 3 ? 2 : 3;

                // Show loader
                $('#loader').show();

                // AJAX request to update status
                $.ajax({
                    type: 'POST',
                    url: 'update_seller_status.php',
                    data: {
                        sellerId: sellerId,
                        newStatus: newStatus
                    },
                    success: function(response) {
                        // Hide loader
                        $('#loader').hide();
                        // Reload page after successful update
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        // Hide loader
                        $('#loader').hide();
                        console.error('Error updating seller status:', error);
                    }
                });
            });
        });
    </script>
   
    <!-- Scripts -->
     <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
