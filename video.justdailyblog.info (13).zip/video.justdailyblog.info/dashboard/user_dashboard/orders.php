<?php  
session_start();
include "head.php";
include "../../includes/db_conn.php";

if(isset($_POST['submit'])) {
    $shipping = $_POST['shipping'];
    $sql = "UPDATE `shipping_cost` SET `shipping` = '$shipping' WHERE `id` = 2 ";
    $run = mysqli_query($conn, $sql);
    
    if ($run) {
        echo "Shipping cost updated successfully";
    } else {
        echo "Error updating shipping cost: " . $conn->error;
    }
}

$sql = "SELECT `shipping` FROM `shipping_cost` WHERE `id` = 2";
$result = $conn->query($sql);
$fetch = mysqli_fetch_assoc($result);

$user_id = $_SESSION['user_id'];
$select_user_email = "SELECT email FROM users WHERE id = $user_id";
$result_user_email = mysqli_query($conn, $select_user_email);
$user_email_row = mysqli_fetch_assoc($result_user_email);
$seller_email = $user_email_row['email'];

// Updated query to fetch orders with product details
$select_orders = "SELECT o.*, p.upload AS product_image, p.title AS product_title, p.price AS product_price
                  FROM orders o
                  INNER JOIN products p ON o.product_id = p.id";
$result_orders = mysqli_query($conn, $select_orders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <main id="main" class="main mt-5">
        <div class="pagetitle"></div>
        <form method="POST">
            <div class="form-group d-flex ">
                <input class="form-control rounded-0" value="<?= $fetch['shipping'] ?>" style="width:250px;" type="number" min="1" step="any" name="shipping" required="">
                <input class="btn bg-dark text-white rounded-0" value="Update Shipping cost" type="submit" name="submit">
            </div>
        </form>
        <table class="table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Billing Address</th>
                    <th>Buyer Name</th>
                    <th>Buyer Email</th>
                    <th>Buyer Number</th>
                    <th>Order Date</th>
                    <th>Payment Method</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = mysqli_fetch_assoc($result_orders)) { ?>
                    <tr>
                        <td><a href="../../ecommerce/product-detail.php?id=<?= $order['product_id'] ?>"><img src="../seller_dashboard/<?php echo $order['product_image']; ?>" style="width: 100px;"></a></td>
                        <td><?php echo $order['product_title']; ?></td>
                        <td>€<?php echo $order['product_price']; ?></td>
                        <td><?php echo $order['p_qty']; ?></td>
                        <td><?php echo $order['billing_address']; ?></td>
                        <td><?php echo $order['buyer_name']; ?></td>
                        <td><?php echo $order['buyer_email']; ?></td>
                        <td><?php echo $order['billing_number']; ?></td>
                        <td><?php echo $order['order_date']; ?></td>
                        <td><?php echo $order['payment_method']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
    </main>

    <!-- Include Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Initialize Tooltip -->
    <script>
        // Select all elements with data-bs-toggle="tooltip"
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        // Initialize tooltips
        tooltipTriggerList.forEach(function (tooltipTriggerEl) {
            new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <!-- Include your additional scripts here -->
</body>
</html>
