<?php
include "head.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            padding: 20px;
        }

        #chat-messages {
            border: 1px solid #ccc;
            height: 400px;
            overflow-y: scroll;
            padding: 10px;
        }

        .message {
            padding: 5px;
            margin: 5px 0;
            border-radius: 5px;
        }

        .admin-message {
            background-color: #007bff;
            color: #fff;
            text-align: right;
        }

        .user-message {
            background-color: #f0f0f0;
            color: #000;
            text-align: left;
        }

        .input-group {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <main id="main" class="main">
        <div class="container">
            <h1 class="text-center">Live Chat (Admin)</h1>
            <div id="chat-messages" class="border rounded p-2 mb-3">
              <?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location:../../buyer_login.php");
    exit;
}

include '../../includes/db_conn.php';

// Fetch the latest message of each user, excluding admin replies
$sql = "SELECT MAX(timestamp) AS max_timestamp, user_id FROM messages WHERE is_admin_reply = 0 GROUP BY user_id";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['user_id'];
        $max_timestamp = $row['max_timestamp'];
        
        // Fetch the latest message of the user
        $latest_message_query = "SELECT * FROM messages WHERE user_id = $user_id AND timestamp = '$max_timestamp'";
        $latest_message_result = mysqli_query($conn, $latest_message_query);
        
        if (mysqli_num_rows($latest_message_result) > 0) {
            $latest_message_row = mysqli_fetch_assoc($latest_message_result);
            $timestamp = $latest_message_row['timestamp'];
            // Display the latest message
            ?>
            <a href="view_user_messages.php?user_id=<?php echo $user_id; ?>" style="text-decoration:none;">
            <div style="margin-bottom: 10px; padding: 10px; background-color: #f0f0f0; border-radius: 5px; position: relative;">
                <span style="background-color: #eeeeee; padding: 10px; border-radius: 50%; margin-right: 10px;">
                    <i class="fa-regular fa-user" style="color: black;"></i>
                </span>
                <strong style="color: black; margin-right: 10px;"><?php echo $latest_message_row["username"]; ?>:</strong> <br>
                <span style="color: #333; margin-left: 40px;"><?php echo $latest_message_row["message"]; ?></span>
                <span style="position: absolute;font-size:12px; bottom: 5px; right: 10px; color: #888;"><?php echo $timestamp; ?></span><br>
            </div>
            </a>
            <?php
        }
    }
} else {
    echo "No messages yet.";
}

mysqli_close($conn);
?>

            </div>
            <!--<div class="input-group">-->
            <!--    <input type="text" id="message" class="form-control" placeholder="Type your message...">-->
            <!--    <div class="input-group-append">-->
            <!--        <button id="send-btn" class="btn btn-primary">Send</button>-->
            <!--    </div>-->
            <!--</div>-->
        </div>
    </main>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    </script>
     <script src="../assets/js/main.js"></script>
       <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
     
</body>

</html>
