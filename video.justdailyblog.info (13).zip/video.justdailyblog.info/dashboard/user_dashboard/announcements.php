<?php
include "head.php";
include "../../includes/db_conn.php";

if(isset($_POST['submit'])) {
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Allowed file types
    $allowedExtensions = array("jpeg", "jpg", "png");
    $allowedMimeTypes = array("image/jpeg", "image/jpg", "image/png");

    // Check if the uploaded file is of an allowed type
    $fileExtension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $fileMimeType = mime_content_type($_FILES["image"]["tmp_name"]);

    if (!in_array($fileExtension, $allowedExtensions) || !in_array($fileMimeType, $allowedMimeTypes)) {
        // Display error message or handle the error in any other way
        // You can leave this part empty if you don't want to show any message
    } else {
        $uploadDir = "uploads/";
        $uploadFile = $uploadDir . basename($_FILES["image"]["name"]);
         $errormessage = "Failed to upload image, Please choose another format";

        // Move the uploaded file to the desired location
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadFile)) {
            // Insert data into the database
            $insert = "INSERT INTO `adspace` (`start_time`, `end_time`, `image`) VALUES ('$start_time', '$end_time', '$uploadFile')";
            $sql = mysqli_query($conn, $insert);

            if ($sql) {
                // Set success message
                $successmessage = "Adspace Added";
            } else {
                // Set error message
                $errormessage = "Failed to insert data into the database";
            }
        } else {
            // Set error message
            $errormessage = "Failed to upload image";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<body>


    <main id="main" class="main mt-5">
        

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModals" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" enctype="multipart/form-data">
    <label for="formFileLg" class="form-label">Upload Image</label>
    <input type="datetime-local" name="start_time" class="form-control form-control-lg" required>
    <input type="datetime-local" name="end_time" class="form-control form-control-lg" required>
	<input class="form-control form-control-lg" id="formFileLg" type="file" name="image" accept=".jpeg, .jpg, .png" required>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
        	<button type="submit" class="btn btn-primary" name="submit">Addspace</button>
</form>
      </div>
    </div>
  </div>
</div>
        
        <!--modal-->
        <!-- Button trigger modal -->
            <div class="d-flex justify-content-end" style="gap: 10px;">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModals">
  Add Adspace
</button>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
              Create an Announcement
            </button>
            </div>
<?php
if(isset($errormessage)) {
    echo "<div class='alert alert-danger'>" . $errormessage . "</div>";
}
if(isset($successmessage)) {
    echo "<div class='alert alert-success'>" . $successmessage . "</div>";
}
?>
            
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Creating Announcement</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                  <div class="container">
                      <div class="row justify-content-center">
                        <div class="col-12">
                          <form action="create_announcement.php" method="post">
                            <div class="form-group">
                              <label for="content">Announcement Content:</label>
                              <textarea class="form-control" id="content" name="content" rows="1" required></textarea>
                            </div>
<div class="col-12 d-flex gap-2">
    <div class="form-group col-6">
        <label for="start_time">Start Time:</label>
        <input type="datetime-local" class="form-control" id="start_time" name="start_time" required>
    </div>
    <div class="form-group col-6">
        <label for="end_time">End Time:</label>
        <input type="datetime-local" class="form-control" id="end_time" name="end_time" required>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const startTimeInput = document.getElementById("start_time");
        const endTimeInput = document.getElementById("end_time");

        // Disable past dates
        const currentDate = new Date().toISOString().split("T")[0];
        startTimeInput.min = currentDate;
        endTimeInput.min = currentDate;

        // Add event listener to the start time input field
        startTimeInput.addEventListener("input", function() {
            // Get the selected start time value
            const startTimeValue = new Date(this.value).getTime();

            // Disable end time inputs before the selected start time
            const endTimeInputs = document.querySelectorAll("#end_time");
            endTimeInputs.forEach(function(endTimeInput) {
                // Convert the current end time input value to milliseconds
                const endTimeValue = new Date(endTimeInput.value).getTime();

                // Disable the end time input if it's before the selected start time
                if (endTimeValue < startTimeValue) {
                    endTimeInput.value = "";
                    endTimeInput.disabled = true;
                } else {
                    endTimeInput.disabled = false;
                }
            });
        });
    });
</script>

                            <div class="form-group">
                              <label for="target_audience">Target Audience:</label>
                             <select class="form-control" id="target_audience" name="target_audience">
                                <option value="sellers">Sellers</option>
                                <option value="specific_users">Users</option>
                                <option value="all">All</option>
                            </select>
                                                        </div>
                            <button type="submit" class="btn btn-primary w-100 mt-3">Create Announcement</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        <!--modal-->
      

        <!-- Announcements Table -->
    <div class="container mt-5">
    <h2>All Announcements</h2>
    <?php
$sql = "SELECT * FROM announcements";
$result = mysqli_query($conn, $sql);
?>
<table class="table mt-3 vertical-lines">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Announcement Content</th>
            <th scope="col">Start Time</th>
            <th scope="col">End Time</th>
            <th scope="col">Audience</th>
            <th scope="col">Created at</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $count = 1;
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <th scope="row"><?php echo $count ?></th>
                    <td><?php echo $row['content'] ?></td>
                    <td><?php echo $row['start_time'] ?></td>
                    <td><?php echo $row['end_time'] ?></td>
                    <td><?php echo $row['target_audience'] ?></td>
                    <td><?php echo $row['created_at'] ?></td>
                    <td>
                        <button class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#updateModal<?php echo $row['id'] ?>'><i class='fa-regular fa-pen-to-square'></i> Update</button>
                    </td>
                    <td>
                        <form action='delete_announcement.php' method='POST' class='d-inline'>
                            <input type='hidden' name='id' value='<?php echo $row['id'] ?>'>
                            <button type='submit' class='btn btn-danger' onclick="return confirm('Are you sure you want to delete this announcement?')"><i class='fas fa-trash-alt'></i> Delete</button>
                        </form>
                    </td>
                </tr>
                <?php
                $count++;
            }
        } else {
            echo "<tr><td colspan='8'>No announcements found</td></tr>";
        }
        ?>
    </tbody>
</table>


</div>

 <!-- Display Ads Table -->
        <div class="container mt-5">
            <h2>All Ads</h2>
            <table class="table">
                <thead>
                    <tr>
                         <th>Image</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch data from database
                    $select_query = "SELECT * FROM adspace";
                    $result = mysqli_query($conn, $select_query);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td><a href='" . $row['image'] . "' target='_blank'><img src='" . $row['image'] . "' height='100px' width='auto'></a></td>";
                            echo "<td>" . $row['start_time'] . "</td>";
                            echo "<td>" . $row['end_time'] . "</td>";
                            echo "<td><a href='delete_ads.php?id=" . $row['id'] . "' class='btn btn-danger'>Delete</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>



    </main>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Scripts -->
    <script>
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
        
        const myModal = document.getElementById('myModal')
        const myInput = document.getElementById('myInput')
        
        myModal.addEventListener('shown.bs.modal', () => {
          myInput.focus()
        })
    </script>




</body>

</html>
