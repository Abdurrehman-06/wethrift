<?php
session_start();
include "../../includes/db_conn.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    // Insert new admin into the database
    $sql = "INSERT INTO users (username, email, password, status) VALUES ('$username', '$email', '$password', 1)"; // Assuming status 1 means admin
    if (mysqli_query($conn, $sql)) {
        // Admin added successfully
        header("Location: admin_panel.php"); // Redirect to admins page or appropriate page
        exit;
    } else {
        // Error occurred while adding admin
        echo "Error: " . mysqli_error($conn);
    }
}
?>
