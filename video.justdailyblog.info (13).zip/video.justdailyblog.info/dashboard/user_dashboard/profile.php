<?php
include "head.php";

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $username = $row['username'];
    $birthdate = $row['birthdate'];
    $phone_number = $row['phone_number'];
    $email = $row['email'];
    $password = $row['password'];
    $profile_image = $row['profile_image']; 
} else {
    echo "User not found.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Handle file upload for profile image
    if ($_FILES['profile_image']['size'] > 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
            $profile_image = $target_file;
            $update_sql = "UPDATE users SET profile_image='$profile_image' WHERE id='$user_id'";
            mysqli_query($conn, $update_sql);
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Handle form submissions for username, birthdate, phone number, etc.
    // Your existing code for handling these form submissions
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $old_password = mysqli_real_escape_string($conn, $_POST['old_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);

    if (!empty($new_password)) { // Check if new password field is not empty
        if (password_verify($old_password, $password)) {
            // Validate new password
            if (strlen($new_password) >= 8) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE users SET username='$username', birthdate='$birthdate', phone_number='$phone_number', password='$hashed_password' WHERE id='$user_id'";
                if (mysqli_query($conn, $update_sql)) {
                    echo "<script>window.location.href='profile.php';</script>";
                    exit;
                } else {
                    echo "Error updating profile: " . mysqli_error($conn);
                }
            } else {
                $errormessage = "New password must be at least 8 characters long.";
            }
        } else {
            $errormessage1 = "Old password is incorrect.";
        }
    } else {
        $update_sql = "UPDATE users SET username='$username', birthdate='$birthdate', phone_number='$phone_number' WHERE id='$user_id'";
        if (mysqli_query($conn, $update_sql)) {
            echo "<script>window.location.href='profile.php';</script>";
            exit;
        } else {
            echo "Error updating profile: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Include Font Awesome library -->
    <style>
        body {
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 550px;
            margin: 10px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="password"],
        input[type="email"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: black;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
      .profile-img {
        position: relative;
        width: 150px;
        height: 150px;
        margin: auto;
        border-radius: 50%;
        overflow: hidden;
        cursor: pointer; /* Make the profile image clickable */
    }

    .profile-img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black overlay */
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .profile-img:hover .overlay {
        opacity: 1;
    }

    .overlay i {
        color: #fff;
        font-size: 24px;
        cursor: pointer;
    }
    </style>
</head>
<body>
<main id="main" class="main mt-5">
    <h2>Profile</h2>
    <form method="post" action="update_profile.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                
                <div class="profile-img" onclick="document.getElementById('file-input').click();">
                    <?php if(!empty($profile_image)): ?>
                        <img src="../user_dashboard/<?php echo $profile_image; ?>" alt="Profile Image">
                    <?php else: ?>
                        <!-- Display a default image if profile image is not set -->
                        <img src="../seller_dashboard/uploads/office.jpg" alt="Default Profile Image">
                    <?php endif; ?>
                    <div class="overlay">
                        <i class="fas fa-camera"></i>
                    </div>
                    <input type="file" name="profile_image" accept="image/*" id="file-input" style="display: none;">
                </div>
                
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>"><br><br>
                
                <label for="birthdate">Birthdate:</label>
                <input type="date" id="birthdate" name="birthdate" value="<?php echo htmlspecialchars($birthdate); ?>"><br><br>
                
                <div class="form-group">
                    <label for="phone_number">Phone Number:</label>
                    <div class="input-group">
                        <span class="input-group-prepend">
                            <span class="input-group-text">
                                <img src="../../assets/img/dashboard/kosovo_flag_icon.png" alt="Kosovo Flag" style="width: 30px; height: auto;"> +383
                            </span>
                        </span>
                        <input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($phone_number); ?>">
                    </div>
                </div><br>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" disabled><br><br>

                <label for="old_password">Old Password:</label>
                <input type="password" id="old_password" name="old_password">
                <br><br>
    
<label for="new_password">New Password:</label>
<input type="password" id="new_password" name="new_password" oninput="validatePassword()"><br>
<small id="password_error" style="color: red; display: none;">Password must be at least 8 characters long</small><br><br>


                <input type="submit" value="Save">
            </form>
</main>
<script>
    setTimeout(function(){
        document.querySelector('.alert').style.display = 'none';
    }, 5000); // Close the alert after 5 seconds (5000 milliseconds)
</script>
<script>
    function validatePassword() {
        var passwordInput = document.getElementById('new_password');
        var errorText = document.getElementById('password_error');

        if (passwordInput.value.length < 8 && passwordInput.value !== '') {
            errorText.style.display = 'block';
        } else {
            errorText.style.display = 'none';
        }
    }

    function validateForm() {
        var passwordInput = document.getElementById('new_password');
        var passwordError = document.getElementById('password_error');
        if (passwordInput.value.length < 8 && passwordInput.value !== '') {
            passwordError.style.display = 'block';
            return false; // Prevent form submission
        }
        return true; // Allow form submission
    }
</script>
</body>
</html>
