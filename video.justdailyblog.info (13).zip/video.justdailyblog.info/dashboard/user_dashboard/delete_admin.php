<?php
// Include database connection
include "../../includes/db_conn.php";

// Check if 'id' parameter is set in the URL
if(isset($_GET['id'])) {
    // Retrieve and sanitize the ID parameter
    $admin_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Construct the SQL query to delete the admin user
    $sql = "DELETE FROM `users` WHERE id = $admin_id";

    // Execute the SQL query
    if(mysqli_query($conn, $sql)) {
        // Redirect back to the page where admins are listed after successful deletion
        header("Location: admin_panel.php");
        exit;
    } else {
        // If deletion fails, show an error message
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If 'id' parameter is not set in the URL, show an error message
    echo "No ID specified for deletion";
}
?>
