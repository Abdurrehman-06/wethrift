<?php
session_start();
include "../../includes/db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['user_id']) && is_numeric($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM messages WHERE user_id = $user_id ORDER BY id ASC";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $messages = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $messages[] = $row;
        }
        echo json_encode($messages);
    } else {
        echo json_encode(["error" => mysqli_error($conn)]);
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply_message']) && isset($_SESSION['user_id'])) {
    $reply_message = mysqli_real_escape_string($conn, $_POST['reply_message']);
    $user_id = $_SESSION['user_id'];
    $insert_query = "INSERT INTO messages (user_id, username, message, is_admin_reply) VALUES ('$user_id', 'Admin', '$reply_message', 1)";
    if (mysqli_query($conn, $insert_query)) {
        // Fetch and return all messages for the user after sending a reply
        $sql = "SELECT * FROM messages WHERE user_id = $user_id ORDER BY id ASC";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $messages = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $messages[] = $row;
            }
            echo json_encode($messages);
        } else {
            echo json_encode(["error" => mysqli_error($conn)]);
        }
    } else {
        echo json_encode(["error" => mysqli_error($conn)]);
    }
} else {
    echo json_encode(["error" => "Invalid request."]);
}

mysqli_close($conn);
?>
