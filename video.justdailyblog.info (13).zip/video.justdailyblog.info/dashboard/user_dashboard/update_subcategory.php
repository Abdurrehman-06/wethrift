<?php
session_start();
include "../../includes/db_conn.php";

if(isset($_POST['categoryId'], $_POST['categoryName'])) {
    $categoryId = $_POST['categoryId'];
    $categoryName = $_POST['categoryName'];
    
    // Update category name in the database
    $sql = "UPDATE subcategories SET sub_categories = '$categoryName' WHERE id = $categoryId";
    $result = mysqli_query($conn, $sql);
    
    if($result) {
        header("Location: categories.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: categories.php");
    exit();
}
?>
