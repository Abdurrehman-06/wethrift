<?php
session_start(); // Start the session
include "../../includes/db_conn.php"; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables to store form data
    $username = $birthdate = $phone_number = $street_address = $profile_image = "";

    // Validate and sanitize form inputs
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $street_address = mysqli_real_escape_string($conn, $_POST['street_address']);

    // Handle file upload for profile image
    if ($_FILES['profile_image']['size'] > 0) {
        $target_dir = "../user_dashboard/uploads/";
        $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
            $profile_image = $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    }

    // Handle password change if old and new passwords are provided
    $old_password = mysqli_real_escape_string($conn, $_POST['old_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);

    if (!empty($old_password) && !empty($new_password)) {
        $select_password_sql = "SELECT password FROM users WHERE id='$user_id'";
        $result = mysqli_query($conn, $select_password_sql);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $password_hash = $row['password'];
            
            // Verify old password
            if (password_verify($old_password, $password_hash)) {
                // Validate new password length
                if (strlen($new_password) >= 8) {
                    // Hash and update new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_password_sql = "UPDATE users SET password='$hashed_password' WHERE id='$user_id'";
                    if (!mysqli_query($conn, $update_password_sql)) {
                        echo "Error updating password: " . mysqli_error($conn);
                        exit;
                    }
                } else {
                    $_SESSION['error_msg'] = "New password must be at least 8 characters long.";
                    header("Location: buyer_dashboard.php");
                    exit;
                }
            } else {
                $_SESSION['error_msg'] = "Old password is incorrect.";
                header("Location: profile.php");
                exit;
            }
        } else {
            echo "Error fetching password: " . mysqli_error($conn);
            exit;
        }
    }

    // Update user profile information
    $update_sql = "UPDATE users SET username='$username', birthdate='$birthdate', phone_number='$phone_number', street_address='$street_address', profile_image='$profile_image' WHERE id='$user_id'";
    if (mysqli_query($conn, $update_sql)) {
        $_SESSION['success_msg'] = "Profile updated successfully.";
        header("Location: profile.php");
        exit;
    } else {
        echo "Error updating profile: " . mysqli_error($conn);
        exit;
    }
}
?>
