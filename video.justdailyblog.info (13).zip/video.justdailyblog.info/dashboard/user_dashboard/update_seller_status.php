<?php
session_start();
include "../../includes/db_conn.php";
require '../../smtp/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['sellerId'], $_POST['newStatus'])) {
    $sellerId = mysqli_real_escape_string($conn, $_POST['sellerId']); // Sanitize the input
    $newStatus = mysqli_real_escape_string($conn, $_POST['newStatus']); // Sanitize the input

        $sellerQuery = "SELECT email FROM users WHERE id = $sellerId";
    $sellerResult = mysqli_query($conn, $sellerQuery);
    $sellerData = mysqli_fetch_assoc($sellerResult);
    $sellerEmail = $sellerData['email'];
    
    $updateQuery = "UPDATE users SET status = '$newStatus' WHERE id = '$sellerId'";
    $updateResult = mysqli_query($conn, $updateQuery);

    // Rest of your code...


    if ($updateResult) {
        if ($newStatus == 3) {
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = "premium55.web-hosting.com";
                $mail->SMTPAuth = true;
                $mail->Username = "info@form.justdailyblog.info";
                $mail->Password = "xnz;(III.dXJ";
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;
                $mail->setFrom("info@form.justdailyblog.info", "Verify Email");
                $mail->addAddress($sellerEmail);

                $mail->isHTML(true);
                $mail->Subject = 'Account Activated';
                $mail->Body = 'Congratulations, Your account has been activated by the admin. You can now start using your Seller account.';

                // Send email
                $mail->send();
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "Status updated successfully";
        }
    } else {
        echo "Error updating status: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request";
}
?>
