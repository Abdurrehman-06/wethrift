<?php
// Include necessary files and start session if needed
include "../../includes/db_conn.php";

// Check if seller ID is set
if(isset($_POST['sellerId'])) {
    $sellerId = mysqli_real_escape_string($conn, $_POST['sellerId']);
    
    // Query to fetch seller details
    $query = "SELECT * FROM users WHERE id = $sellerId";
    $result = mysqli_query($conn, $query);
    
    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        // Output seller details including image paths
        echo "<p>Username: " . $row['username'] . "</p>";
        echo "<p>Comapny Name: " . $row['company_name'] . "</p>";
        echo "<p>Birth Date: " . $row['birthdate'] . "</p>";
        echo "<p>Phone Number: " . $row['phone_number'] . "</p>";
        echo "<p>Email: " . $row['email'] . "</p>";
        echo "<p>Street Address: " . $row['street_address'] . "</p>";
        echo "<p>Join Date: " . $row['join_date'] . "</p>";
        echo "<p>Front ID Image: <a href='../../" . $row['id_front'] . "' target='_blank'><img src='../../" . $row['id_front'] . "' alt='Front ID Image' style='width: 200px; height: auto;'></a></p>";
        echo "<p>Back ID Image: <a href='../../" . $row['id_back'] . "' target='_blank'><img src='../../" . $row['id_back'] . "' alt='Back ID Image' style='width: 200px; height: auto;'></a></p>";
    } else {
        echo "Seller not found.";
    }
} else {
    echo "Seller ID not provided.";
}
?>
