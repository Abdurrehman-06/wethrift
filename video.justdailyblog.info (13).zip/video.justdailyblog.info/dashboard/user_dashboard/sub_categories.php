<?php 
    include "head.php";
include "../../includes/db_conn.php";
  
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST['submit'])) {
       
        $categories_id = $_POST['categories_id'];
        $sub_categories =  $_POST['sub_categories'];

   
        $insert_query = "INSERT INTO `subcategories` (`categories_id` , `sub_categories`) VALUES ('$categories_id', '$sub_categories')";
        $result = mysqli_query($conn, $insert_query);
        
        if ($result) {
            echo "";
        } else {
           
        }
    } else {
        echo "Please fill all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
            <main id="main" class="main mt-5">
<form method="POST">
    <select name="categories_id" class="form-select">
        <option selected>select category</option>

        <?php 
        $categories_query = "SELECT * FROM `categories`";
        $categories_result = mysqli_query($conn, $categories_query);
        if ($categories_result && mysqli_num_rows($categories_result) > 0) {
            while ($category = mysqli_fetch_assoc($categories_result)) {
                ?>
                <option value="<?= $category['id']; ?>"><?= $category['categories']; ?></option>
                <?php 
            }
        } else {
            echo "No categories available";
        }
        ?>
    </select>
    <div class="form-group">
        <label>Subcategories</label>
        <input type="text" class="form-control" name="sub_categories">
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
                </main>
    </body>
</html>