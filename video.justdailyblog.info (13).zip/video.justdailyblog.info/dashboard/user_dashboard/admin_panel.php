<?php
session_start();
include "../../includes/db_conn.php";
include "head.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location:../../login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$sql_status = "SELECT status FROM users WHERE id = '$user_id'";
$result_status = mysqli_query($conn, $sql_status);
$user_data = mysqli_fetch_assoc($result_status);
$user_status = $user_data['status'];
if ($user_status == 5) {
    $showActions = true; // Flag to determine if actions should be shown
} else {
    $showActions = false;
}

$sql = "SELECT * FROM `users` WHERE STATUS = '1'";
$data = mysqli_query($conn, $sql);

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    // Insert new admin into the database
    $sql = "INSERT INTO users (username, email, password, status) VALUES ('$username', '$email', '$password', 1)"; // Assuming status 1 means admin
    if (mysqli_query($conn, $sql)) {
        // Admin added successfully
        header("Location: ../../admins.php"); // Redirect to admins page or appropriate page
        exit;
    } else {
        // Error occurred while adding admin
        echo "Error: " . mysqli_error($conn);
    }
}
?>
?>

<!DOCTYPE html>
<html lang="en">
<body>

<main id="main" class="main mt-5">
    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 d-flex justify-content-end my-3 ">
                    <?php if ($showActions) { ?>
                        <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                              Add Admin
                            </button>
                            
                            <!-- Modal -->
                        <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add Admin</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body">
                                    <form action="add_admin.php" method="POST">
                                      <div class="mb-3">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" required>
                                      </div>
                                      <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                      </div>
                                      <div class="mb-3">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                      </div>
                                      <button type="submit" name='submit' class="btn btn-primary">Submit</button>
                                    </form>
                                  </div>
                                </div>
                              </div>
                            </div>

                    <?php } ?>
                </div>
                <div class="col-lg-12">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Email</th>
                              <?php if ($showActions) { ?>
                            <th id='show' >Actions</th>
                                   <?php } ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $count = 1;
                        while ($result = mysqli_fetch_assoc($data)) {
                            echo "
                            <tr>
                                <td>$count</td>
                                <td>{$result['username']}</td>
                                <td>{$result['email']}</td>";
                            if ($showActions) {
                                echo "
                                <td id='show'>
                                    <a href='delete_admin.php?id={$result['id']}' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this user?\")'><i class='fas fa-trash-alt'></i> Delete</a>
                                </td>";
                            }
                            echo "
                            </tr>";
                            $count++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<!-- Scripts -->
<script>
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
</script>
<script src="../assets/js/main.js"></script>
<!-- Vendor JS Files -->
<script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/chart.js/chart.umd.js"></script>
<script src="assets/vendor/echarts/echarts.min.js"></script>
<script src="assets/vendor/quill/quill.min.js"></script>
<script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="assets/vendor/tinymce/tinymce.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<!-- Template Main JS File -->
<script src="../assets/js/main.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"
        integrity="sha512-BCfBSZNW3NGX1Hg6P6btgQ9YTPdh2h4k/2ZRISJ2M9XlBz0ZmcY33/CbRJ6W9HsKnxYl/sB3aYjdwR9IlQdNzg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>
