<?php
include "../../includes/db_conn.php";
$content = $_POST['content'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$target_audience = $_POST['target_audience'];
$sql = "INSERT INTO announcements (content, start_time, end_time, target_audience) 
        VALUES ('$content', '$start_time', '$end_time', '$target_audience')";

if (mysqli_query($conn, $sql)) {
    echo "
    <script>
   window.location.href = 'announcements.php';
    </script>
    ";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close database connection
mysqli_close($conn);
?>
