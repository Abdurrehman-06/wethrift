<?php
session_start();
include "../../includes/db_conn.php";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_seller'])) {
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $seller_id = $_POST['id'];
        $stmt = "DELETE FROM users WHERE id = $seller_id";
        mysqli_query($conn, $stmt);
        header("Location:sellers.php");
    }
}
header("Location:sellers.php");
exit();
?>

