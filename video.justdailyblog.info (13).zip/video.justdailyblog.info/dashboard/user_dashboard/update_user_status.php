<?php
session_start();
include "../../includes/db_conn.php";
require '../../smtp/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['user_id'], $_POST['newStatus'])) {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $newStatus = mysqli_real_escape_string($conn, $_POST['newStatus']);
    $userQuery = "SELECT email FROM users WHERE id = '$user_id'";
    $userResult = mysqli_query($conn, $userQuery);
    $userData = mysqli_fetch_assoc($userResult);
    $userEmail = $userData['email'];
    $updateQuery = "UPDATE users SET status = '$newStatus' WHERE id = '$user_id'";
    $updateResult = mysqli_query($conn, $updateQuery);

    if ($updateResult) {
        if ($_POST['currentStatus'] == 0 && $newStatus == 4) {
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = "premium55.web-hosting.com";
                $mail->SMTPAuth = true;
                $mail->Username = "info@form.justdailyblog.info";
                $mail->Password = "xnz;(III.dXJ";
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;
                $mail->setFrom("info@form.justdailyblog.info", "Verify Email");
                $mail->addAddress($userEmail);

                $mail->isHTML(true);
                $mail->Subject = 'Account Activated';
                $mail->Body = 'Congratulations, Your account has been activated by the admin. You can now start using your account.';

                // Send email
                $mail->send();
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }

        echo "Status updated successfully";
    } else {
        echo "Error updating status: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request";
}
?>
