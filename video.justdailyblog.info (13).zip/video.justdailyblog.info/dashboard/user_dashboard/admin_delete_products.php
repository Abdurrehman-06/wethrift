<?php
session_start();
include "../../includes/db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_product'])) {
    if(isset($_POST['id']) && !empty($_POST['id'])) {
        $id = $_POST['id'];

        // Prepare the SQL statement to delete the product
        $sql = "DELETE FROM products WHERE id = ?";
        
        // Prepare the statement
        $stmt = mysqli_prepare($conn, $sql);
        
        // Bind parameters and execute the statement
        mysqli_stmt_bind_param($stmt, "i", $id);
        $success = mysqli_stmt_execute($stmt);

        // Check if the deletion was successful
        if ($success) {
            header("Location: products.php?success=Product deleted successfully.");
            exit();
        } else {
            header("Location: products.php?error=Error deleting product.");
            exit();
        }
    } else {
        header("Location: products.php?error=Product ID not provided.");
        exit();
    }
} else {
    header("Location: products.php?error=Invalid request.");
    exit();
}
?>
