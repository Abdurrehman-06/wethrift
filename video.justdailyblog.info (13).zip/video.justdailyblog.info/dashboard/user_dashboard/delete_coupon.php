<?php
session_start();
include "../../includes/db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $couponId = $_POST['id'];
    $sql = "DELETE FROM coupons WHERE id = ?";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters
    $stmt->bind_param("i", $couponId);
    
    // Execute statement
    if ($stmt->execute()) {
        header("Location: coupons.php");
        exit();
    } else {
        // Error deleting coupon
        $_SESSION['error_message'] = "Error deleting coupon: " . $conn->error;
        header("Location: coupons.php");
        exit();
    }
} else {
    header("Location: coupons.php");
    exit();
}
?>
