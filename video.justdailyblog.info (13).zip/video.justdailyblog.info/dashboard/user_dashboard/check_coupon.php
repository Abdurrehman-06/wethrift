<?php
include "config.php"; // Include your database connection configuration file

if (isset($_POST['coupon-code'])) {
    $couponCode = $_POST['coupon-code'];
    $checkSql = "SELECT * FROM coupons WHERE coupon_code = '$couponCode'";
    $checkResult = mysqli_query($conn, $checkSql);

    if (mysqli_num_rows($checkResult) > 0) {
        echo 'exists';
    } else {
        // Coupon code doesn't exist
    }
}
?>
