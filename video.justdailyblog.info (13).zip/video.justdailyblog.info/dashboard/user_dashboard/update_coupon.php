<?php
session_start();
include "../../includes/db_conn.php";

if (isset($_POST['update_coupon'])) {
    $couponId = $_POST['id'];
    $couponCode = $_POST['coupon-code'];
    $discount = $_POST['discount'];
    $startDate = $_POST['start-date'];
    $endDate = $_POST['end-date'];

    // Update the coupon in the database
    $sql = "UPDATE coupons SET coupon_code = '$couponCode', discount = '$discount', start_date = '$startDate', end_date = '$endDate' WHERE id = '$couponId'";
    if (mysqli_query($conn, $sql)) {
        echo "Coupon updated successfully";
    } else {
        echo "Error updating coupon: " . mysqli_error($conn);
    }
}

// Redirect back to the page where the edit button was clicked
header("Location: {$_SERVER['HTTP_REFERER']}");
exit();
?>
